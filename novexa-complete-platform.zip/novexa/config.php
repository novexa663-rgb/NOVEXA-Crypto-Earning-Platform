<?php
session_start();
date_default_timezone_set('Asia/Kolkata');

// Database
$host = 'localhost';
$dbname = 'novexa_mlm';
$dbuser = 'novexa_user';
$dbpass = 'Novexa@2025';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $dbuser, $dbpass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Database connection failed");
}

// Site settings cache
function getSetting($key, $default = '') {
    global $pdo;
    try {
        $stmt = $pdo->prepare("SELECT setting_value FROM settings WHERE setting_key = ?");
        $stmt->execute([$key]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row ? $row['setting_value'] : $default;
    } catch(Exception $e) {
        return $default;
    }
}

// Auth check
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: login.php');
        exit;
    }
}

function requireAdmin() {
    if (!isset($_SESSION['admin_id'])) {
        header('Location: admin_login.php');
        exit;
    }
}

// Get user data
function getUser($id) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$id]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

// Generate unique referral code
function generateReferralCode() {
    return 'NVX' . strtoupper(substr(md5(uniqid()), 0, 6));
}

// Format money
function money($amount) {
    return '$' . number_format((float)$amount, 2);
}

// Get unread notifications count
function getUnreadCount($userId) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0");
    $stmt->execute([$userId]);
    return $stmt->fetchColumn();
}

// Get active announcements
function getActiveAnnouncements() {
    global $pdo;
    $stmt = $pdo->query("SELECT * FROM announcements WHERE is_active = 1 AND (start_date IS NULL OR start_date <= NOW()) AND (end_date IS NULL OR end_date >= NOW()) ORDER BY is_pinned DESC, priority DESC, created_at DESC");
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Add notification
function addNotification($userId, $title, $message, $type = 'system') {
    global $pdo;
    $stmt = $pdo->prepare("INSERT INTO notifications (user_id, title, message, type) VALUES (?, ?, ?, ?)");
    $stmt->execute([$userId, $title, $message, $type]);
}

// Add transaction record
function addTransaction($userId, $type, $amount, $coinType = 'internal', $desc = '', $refId = null) {
    global $pdo;
    $user = getUser($userId);
    $balanceAfter = $user['total_balance'];
    $stmt = $pdo->prepare("INSERT INTO transactions (user_id, type, amount, balance_after, coin_type, description, reference_id) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$userId, $type, $amount, $balanceAfter, $coinType, $desc, $refId]);
}

// Flash messages
function setFlash($type, $message) {
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function getFlash() {
    if (isset($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}
?>
