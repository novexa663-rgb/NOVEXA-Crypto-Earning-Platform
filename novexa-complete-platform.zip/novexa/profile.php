<?php
require_once 'config.php';
requireLogin();
$pageTitle = 'Profile';
$user = getUser($_SESSION['user_id']);

// Handle profile update
if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if($action === 'update_profile') {
        $fullname = trim($_POST['full_name'] ?? '');
        $mobile = trim($_POST['mobile'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $pdo->prepare("UPDATE users SET full_name=?, mobile=?, email=? WHERE id=?")->execute([$fullname, $mobile, $email, $user['id']]);
        setFlash('success', 'Profile updated!');
    }
    elseif($action === 'change_password') {
        $current = $_POST['current_password'] ?? '';
        $newpass = $_POST['new_password'] ?? '';
        $confirm = $_POST['confirm_password'] ?? '';
        if(!password_verify($current, $user['password'])) {
            setFlash('error', 'Current password is incorrect');
        } elseif($newpass !== $confirm) {
            setFlash('error', 'New passwords do not match');
        } elseif(strlen($newpass) < 6) {
            setFlash('error', 'Password must be at least 6 characters');
        } else {
            $pdo->prepare("UPDATE users SET password=? WHERE id=?")->execute([password_hash($newpass, PASSWORD_DEFAULT), $user['id']]);
            setFlash('success', 'Password changed!');
        }
    }
    elseif($action === 'update_wallets') {
        $usdt = trim($_POST['wallet_usdt'] ?? '');
        $sol = trim($_POST['wallet_sol'] ?? '');
        $bnb = trim($_POST['wallet_bnb'] ?? '');
        $pdo->prepare("UPDATE users SET wallet_address_usdt=?, wallet_address_sol=?, wallet_address_bnb=? WHERE id=?")->execute([$usdt, $sol, $bnb, $user['id']]);
        setFlash('success', 'Wallet addresses updated!');
    }
    elseif($action === 'upload_kyc') {
        if(isset($_FILES['kyc_doc']) && $_FILES['kyc_doc']['error'] === 0) {
            $ext = strtolower(pathinfo($_FILES['kyc_doc']['name'], PATHINFO_EXTENSION));
            if(in_array($ext, ['jpg','jpeg','png','pdf'])) {
                $filename = 'kyc_' . $user['id'] . '_' . time() . '.' . $ext;
                move_uploaded_file($_FILES['kyc_doc']['tmp_name'], 'uploads/kyc/' . $filename);
                $pdo->prepare("UPDATE users SET kyc_document=?, kyc_status='submitted' WHERE id=?")->execute([$filename, $user['id']]);
                setFlash('success', 'KYC document uploaded! Pending verification.');
            } else {
                setFlash('error', 'Invalid file type. Use JPG, PNG, or PDF.');
            }
        }
    }
    header('Location: profile.php'); exit;
}

$user = getUser($_SESSION['user_id']); // refresh
include 'includes/header.php';
?>

<div class="grid-2">
  <!-- PROFILE INFO -->
  <div class="card">
    <div class="card-title">👤 Edit Profile</div>
    <form method="POST">
      <input type="hidden" name="action" value="update_profile"/>
      <div class="form-group">
        <label class="form-label">Full Name</label>
        <input type="text" name="full_name" class="form-input" value="<?= htmlspecialchars($user['full_name']) ?>"/>
      </div>
      <div class="form-group">
        <label class="form-label">Email</label>
        <input type="email" name="email" class="form-input" value="<?= htmlspecialchars($user['email']) ?>"/>
      </div>
      <div class="form-group">
        <label class="form-label">Mobile</label>
        <input type="text" name="mobile" class="form-input" value="<?= htmlspecialchars($user['mobile']) ?>"/>
      </div>
      <div class="form-group">
        <label class="form-label">Username</label>
        <input type="text" class="form-input" value="<?= htmlspecialchars($user['username']) ?>" disabled style="opacity:.5;"/>
      </div>
      <div class="form-group">
        <label class="form-label">Referral Code</label>
        <input type="text" class="form-input" value="<?= $user['referral_code'] ?>" disabled style="opacity:.5;"/>
      </div>
      <button type="submit" class="btn btn-primary"><span>UPDATE PROFILE</span></button>
    </form>
  </div>
  
  <!-- RIGHT COLUMN -->
  <div>
    <!-- CHANGE PASSWORD -->
    <div class="card">
      <div class="card-title">🔒 Change Password</div>
      <form method="POST">
        <input type="hidden" name="action" value="change_password"/>
        <div class="form-group">
          <label class="form-label">Current Password</label>
          <input type="password" name="current_password" class="form-input" required/>
        </div>
        <div class="form-group">
          <label class="form-label">New Password</label>
          <input type="password" name="new_password" class="form-input" required/>
        </div>
        <div class="form-group">
          <label class="form-label">Confirm New Password</label>
          <input type="password" name="confirm_password" class="form-input" required/>
        </div>
        <button type="submit" class="btn btn-pink"><span>CHANGE PASSWORD</span></button>
      </form>
    </div>
    
    <!-- KYC -->
    <div class="card">
      <div class="card-title">📄 KYC Verification</div>
      <div style="margin-bottom:16px;">
        Status: <span class="badge badge-<?= $user['kyc_status']==='verified'?'green':($user['kyc_status']==='submitted'?'gold':($user['kyc_status']==='rejected'?'red':'purple')) ?>"><?= strtoupper($user['kyc_status']) ?></span>
      </div>
      <?php if($user['kyc_status'] !== 'verified'): ?>
      <form method="POST" enctype="multipart/form-data">
        <input type="hidden" name="action" value="upload_kyc"/>
        <div class="form-group">
          <label class="form-label">Upload ID Document</label>
          <input type="file" name="kyc_doc" class="form-input" accept="image/*,.pdf" required/>
        </div>
        <button type="submit" class="btn btn-secondary"><span>UPLOAD KYC</span></button>
      </form>
      <?php else: ?>
        <p style="color:var(--green);font-size:.85rem;">✓ Your KYC is verified!</p>
      <?php endif; ?>
    </div>
  </div>
</div>

<!-- WALLET ADDRESSES -->
<div class="card">
  <div class="card-title">📍 Wallet Addresses</div>
  <form method="POST">
    <input type="hidden" name="action" value="update_wallets"/>
    <div class="grid-3">
      <div class="form-group">
        <label class="form-label">USDT (BEP20)</label>
        <input type="text" name="wallet_usdt" class="form-input" value="<?= htmlspecialchars($user['wallet_address_usdt']) ?>" placeholder="USDT BEP20 address"/>
      </div>
      <div class="form-group">
        <label class="form-label">SOL (Solana)</label>
        <input type="text" name="wallet_sol" class="form-input" value="<?= htmlspecialchars($user['wallet_address_sol']) ?>" placeholder="Solana address"/>
      </div>
      <div class="form-group">
        <label class="form-label">BNB (BEP20)</label>
        <input type="text" name="wallet_bnb" class="form-input" value="<?= htmlspecialchars($user['wallet_address_bnb']) ?>" placeholder="BNB BEP20 address"/>
      </div>
    </div>
    <button type="submit" class="btn btn-green"><span>UPDATE WALLETS</span></button>
  </form>
</div>

<!-- SECURITY -->
<div class="card">
  <div class="card-title">🛡️ Security Settings</div>
  <div style="display:flex;justify-content:space-between;align-items:center;padding:12px 0;border-bottom:1px solid var(--border);">
    <div>
      <div style="color:var(--white);font-weight:600;">Two-Factor Authentication</div>
      <div style="font-size:.82rem;">Extra security for your account</div>
    </div>
    <span class="badge badge-<?= $user['two_fa_enabled']?'green':'gold' ?>"><?= $user['two_fa_enabled']?'ENABLED':'DISABLED' ?></span>
  </div>
  <div style="display:flex;justify-content:space-between;align-items:center;padding:12px 0;">
    <div>
      <div style="color:var(--white);font-weight:600;">Last Login</div>
      <div style="font-size:.82rem;"><?= $user['last_login'] ? date('d M Y, H:i', strtotime($user['last_login'])) : 'N/A' ?></div>
    </div>
  </div>
</div>

<?php include 'includes/footer.php'; ?>
