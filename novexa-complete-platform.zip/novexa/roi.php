<?php
require_once 'config.php';
requireLogin();
$pageTitle = 'ROI';
$user = getUser($_SESSION['user_id']);

$stmt = $pdo->prepare("SELECT * FROM roi_history WHERE user_id = ? ORDER BY day_number ASC");
$stmt->execute([$user['id']]); $roiHistory = $stmt->fetchAll(PDO::FETCH_ASSOC);

$totalReleased = 0; $totalRemaining = 0;
foreach($roiHistory as $r) {
    if($r['status'] === 'released') $totalReleased += $r['daily_amount'];
    else $totalRemaining += $r['daily_amount'];
}

$totalROI = $user['active_package'] === 'upgrade' ? 200 : 0;
$daysCompleted = count(array_filter($roiHistory, fn($r) => $r['status'] === 'released'));
$progress = $totalROI > 0 ? min(100, ($totalReleased / $totalROI) * 100) : 0;

include 'includes/header.php';
?>

<div class="stat-grid">
  <div class="stat-card purple">
    <div class="stat-label">Total ROI</div>
    <div class="stat-value"><?= money($totalROI) ?></div>
    <div class="stat-sub">2X of $100</div>
  </div>
  <div class="stat-card green">
    <div class="stat-label">Released</div>
    <div class="stat-value"><?= money($totalReleased) ?></div>
    <div class="stat-sub"><?= $daysCompleted ?> days</div>
  </div>
  <div class="stat-card gold">
    <div class="stat-label">Remaining</div>
    <div class="stat-value"><?= money($totalROI - $totalReleased) ?></div>
    <div class="stat-sub"><?= max(0, 100 - $daysCompleted) ?> days left</div>
  </div>
  <div class="stat-card pink">
    <div class="stat-label">Daily Rate</div>
    <div class="stat-value">$2.00</div>
    <div class="stat-sub">Per day</div>
  </div>
</div>

<!-- PROGRESS -->
<div class="card">
  <div class="card-title">📈 ROI Progress</div>
  <?php if($user['active_package'] === 'upgrade'): ?>
    <div style="display:flex;justify-content:space-between;font-size:.82rem;margin-bottom:8px;">
      <span>Progress: <?= round($progress) ?>%</span>
      <span style="color:var(--v2);"><?= $daysCompleted ?>/100 days</span>
    </div>
    <div class="progress" style="height:8px;"><div class="progress-bar green" style="width:<?= $progress ?>%"></div></div>
    <?php if($user['package_date']): ?>
      <div style="margin-top:12px;font-size:.8rem;">
        Started: <strong style="color:var(--white);"><?= date('d M Y', strtotime($user['package_date'])) ?></strong> &nbsp;|&nbsp;
        Ends: <strong style="color:var(--white);"><?= date('d M Y', strtotime($user['package_date'] . ' +100 days')) ?></strong>
      </div>
    <?php endif; ?>
  <?php else: ?>
    <div style="text-align:center;padding:30px;">
      <div style="font-size:2rem;margin-bottom:8px;">📦</div>
      <p>ROI is available for Upgrade ($100) package only.</p>
      <a href="deposit.php?upgrade=1" class="btn btn-primary" style="margin-top:16px;display:inline-flex;"><span>UPGRADE NOW →</span></a>
    </div>
  <?php endif; ?>
</div>

<!-- ROI TABLE -->
<div class="card">
  <div class="card-title">📋 Daily ROI History</div>
  <div class="table-wrap">
    <table>
      <thead><tr><th>Day</th><th>Amount</th><th>Total Released</th><th>Status</th><th>Date</th></tr></thead>
      <tbody>
        <?php if(empty($roiHistory)): ?>
          <tr><td colspan="5" style="text-align:center;padding:24px;">No ROI history yet</td></tr>
        <?php else: foreach($roiHistory as $r): ?>
          <tr>
            <td style="color:var(--white);font-weight:600;">Day <?= $r['day_number'] ?></td>
            <td style="color:var(--green);"><?= money($r['daily_amount']) ?></td>
            <td><?= money($r['total_released']) ?></td>
            <td><span class="badge badge-<?= $r['status']==='released'?'green':($r['status']==='pending'?'gold':'cyan') ?>"><?= strtoupper($r['status']) ?></span></td>
            <td><?= date('d M Y', strtotime($r['release_date'])) ?></td>
          </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php include 'includes/footer.php'; ?>
