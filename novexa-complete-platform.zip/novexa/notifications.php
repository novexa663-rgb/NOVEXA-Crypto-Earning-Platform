<?php
require_once 'config.php';
requireLogin();
$pageTitle = 'Notifications';
$user = getUser($_SESSION['user_id']);

// Mark all as read
if(isset($_GET['markread'])) {
    $pdo->prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ?")->execute([$user['id']]);
    header('Location: notifications.php'); exit;
}

$stmt = $pdo->prepare("SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 50");
$stmt->execute([$user['id']]); $notifs = $stmt->fetchAll(PDO::FETCH_ASSOC);

include 'includes/header.php';
?>

<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;">
  <div style="font-size:.85rem;"><?= count(array_filter($notifs, fn($n)=>!$n['is_read'])) ?> unread notifications</div>
  <a href="?markread=1" class="btn btn-sm btn-secondary">✓ MARK ALL READ</a>
</div>

<div class="card">
  <?php if(empty($notifs)): ?>
    <div style="text-align:center;padding:40px;color:var(--text);">
      <div style="font-size:2rem;margin-bottom:8px;">🔔</div>
      <p>No notifications yet</p>
    </div>
  <?php else: foreach($notifs as $n): ?>
    <div style="display:flex;gap:12px;padding:14px;border-bottom:1px solid var(--border);background:<?= $n['is_read']?'transparent':'rgba(168,85,247,.03)' ?>;">
      <div style="font-size:1.2rem;">
        <?php
        $icons = ['income'=>'💰','withdrawal'=>'🏧','system'=>'⚙️','announcement'=>'📢','security'=>'🔒'];
        echo $icons[$n['type']] ?? '🔔';
        ?>
      </div>
      <div style="flex:1;">
        <div style="color:var(--white);font-weight:600;font-size:.88rem;"><?= htmlspecialchars($n['title']) ?></div>
        <div style="font-size:.82rem;margin-top:2px;"><?= htmlspecialchars($n['message']) ?></div>
        <div style="font-family:'JetBrains Mono',monospace;font-size:.62rem;color:rgba(156,163,175,.5);margin-top:6px;"><?= date('d M Y, H:i', strtotime($n['created_at'])) ?></div>
      </div>
      <?php if(!$n['is_read']): ?>
        <div style="width:8px;height:8px;border-radius:50%;background:var(--v2);margin-top:6px;"></div>
      <?php endif; ?>
    </div>
  <?php endforeach; endif; ?>
</div>

<?php include 'includes/footer.php'; ?>
