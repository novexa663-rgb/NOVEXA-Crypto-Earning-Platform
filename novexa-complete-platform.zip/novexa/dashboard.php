<?php
require_once 'config.php';
requireLogin();
$pageTitle = 'Dashboard';
$user = getUser($_SESSION['user_id']);

// Get stats
$stmt = $pdo->prepare("SELECT COALESCE(SUM(amount),0) as total FROM income WHERE user_id = ? AND type = 'roi'");
$stmt->execute([$user['id']]); $roiTotal = $stmt->fetchColumn();

$stmt = $pdo->prepare("SELECT COALESCE(SUM(amount),0) as total FROM income WHERE user_id = ? AND type = 'referral'");
$stmt->execute([$user['id']]); $refTotal = $stmt->fetchColumn();

$stmt = $pdo->prepare("SELECT COALESCE(SUM(amount),0) as total FROM income WHERE user_id = ? AND type = 'direct_sponsor'");
$stmt->execute([$user['id']]); $directTotal = $stmt->fetchColumn();

$stmt = $pdo->prepare("SELECT COALESCE(SUM(amount),0) as total FROM income WHERE user_id = ? AND type = 'binary'");
$stmt->execute([$user['id']]); $binaryTotal = $stmt->fetchColumn();

$stmt = $pdo->prepare("SELECT COALESCE(SUM(amount),0) as total FROM withdrawals WHERE user_id = ? AND status = 'approved'");
$stmt->execute([$user['id']]); $totalWithdrawn = $stmt->fetchColumn();

$stmt = $pdo->prepare("SELECT COUNT(*) FROM referrals WHERE sponsor_id = ?");
$stmt->execute([$user['id']]); $totalRefs = $stmt->fetchColumn();

// Recent income for chart (last 7 days)
$stmt = $pdo->prepare("SELECT DATE(created_at) as dt, SUM(amount) as total FROM income WHERE user_id = ? AND created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY) GROUP BY DATE(created_at) ORDER BY dt ASC");
$stmt->execute([$user['id']]); $chartData = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Recent transactions
$stmt = $pdo->prepare("SELECT * FROM transactions WHERE user_id = ? ORDER BY created_at DESC LIMIT 8");
$stmt->execute([$user['id']]); $recentTxns = $stmt->fetchAll(PDO::FETCH_ASSOC);

$refLink = 'https://novexa.org.in/register.php?ref=' . $user['referral_code'];

include 'includes/header.php';
?>

<!-- STAT CARDS -->
<div class="stat-grid">
  <div class="stat-card purple">
    <div class="stat-label">Total Balance</div>
    <div class="stat-value"><?= money($user['total_balance']) ?></div>
    <div class="stat-sub">Available to withdraw</div>
  </div>
  <div class="stat-card pink">
    <div class="stat-label">ROI Income</div>
    <div class="stat-value"><?= money($roiTotal) ?></div>
    <div class="stat-sub">Daily credits</div>
  </div>
  <div class="stat-card gold">
    <div class="stat-label">Referral Income</div>
    <div class="stat-value"><?= money($refTotal) ?></div>
    <div class="stat-sub"><?= $totalRefs ?> referrals</div>
  </div>
  <div class="stat-card cyan">
    <div class="stat-label">Direct Sponsor</div>
    <div class="stat-value"><?= money($directTotal) ?></div>
    <div class="stat-sub">10% instant</div>
  </div>
  <div class="stat-card green">
    <div class="stat-label">Binary Income</div>
    <div class="stat-value"><?= money($binaryTotal) ?></div>
    <div class="stat-sub">Weekly matching</div>
  </div>
  <div class="stat-card red">
    <div class="stat-label">Total Withdrawn</div>
    <div class="stat-value"><?= money($totalWithdrawn) ?></div>
    <div class="stat-sub">All time</div>
  </div>
</div>

<!-- QUICK BUTTONS -->
<div class="card">
  <div class="card-title">⚡ Quick Actions</div>
  <div style="display:flex;gap:12px;flex-wrap:wrap;">
    <a href="deposit.php" class="btn btn-primary"><span>💳 DEPOSIT</span></a>
    <a href="withdraw.php" class="btn btn-pink"><span>🏧 WITHDRAW</span></a>
    <a href="deposit.php?upgrade=1" class="btn btn-green"><span>⬆️ UPGRADE</span></a>
    <button class="btn btn-secondary" onclick="copyText('<?= $refLink ?>')">📋 COPY REFERRAL</button>
  </div>
</div>

<!-- REFERRAL LINK -->
<div class="card">
  <div class="card-title">🔗 Your Referral Link</div>
  <div class="copy-wrap">
    <input type="text" class="form-input" value="<?= $refLink ?>" readonly id="refLink"/>
    <button class="copy-btn" onclick="copyText('<?= $refLink ?>')">COPY</button>
  </div>
  <div style="margin-top:10px;font-family:'JetBrains Mono',monospace;font-size:.7rem;color:var(--v2);">
    Your Code: <strong><?= $user['referral_code'] ?></strong> &nbsp;|&nbsp; Package: <strong><?= strtoupper($user['active_package']) ?></strong>
  </div>
</div>

<!-- CHARTS + RECENT -->
<div class="grid-2">
  <!-- Earnings Chart -->
  <div class="card">
    <div class="card-title">📈 7-Day Earnings</div>
    <canvas id="earningsChart" height="200"></canvas>
  </div>
  
  <!-- Active Package -->
  <div class="card">
    <div class="card-title">📦 Package Info</div>
    <?php if($user['active_package'] !== 'none'): ?>
      <div style="text-align:center;padding:20px 0;">
        <div style="font-size:2.5rem;margin-bottom:8px;"><?= $user['active_package'] === 'upgrade' ? '💎' : '⭐' ?></div>
        <div style="font-family:'Syne',sans-serif;font-size:1.6rem;font-weight:800;color:var(--white);"><?= money($user['package_amount']) ?></div>
        <div style="font-family:'JetBrains Mono',monospace;font-size:.65rem;color:var(--v2);letter-spacing:2px;margin-top:4px;"><?= strtoupper($user['active_package']) ?> PACKAGE</div>
        <div style="font-size:.82rem;margin-top:12px;">Activated: <?= date('d M Y', strtotime($user['package_date'])) ?></div>
        <?php if($user['active_package'] === 'upgrade'): ?>
          <?php 
            $daysPassed = (time() - strtotime($user['package_date'])) / 86400;
            $progress = min(100, ($daysPassed/100)*100);
          ?>
          <div style="margin-top:12px;">
            <div style="font-size:.75rem;">ROI Progress: <?= round($progress) ?>%</div>
            <div class="progress"><div class="progress-bar purple" style="width:<?= $progress ?>%"></div></div>
          </div>
        <?php endif; ?>
      </div>
    <?php else: ?>
      <div style="text-align:center;padding:30px 0;color:var(--text);">
        <div style="font-size:2rem;margin-bottom:8px;">📦</div>
        <p>No active package</p>
        <a href="deposit.php" class="btn btn-primary" style="margin-top:16px;display:inline-flex;"><span>ACTIVATE NOW →</span></a>
      </div>
    <?php endif; ?>
  </div>
</div>

<!-- RECENT TRANSACTIONS -->
<div class="card">
  <div class="card-title">📋 Recent Transactions</div>
  <div class="table-wrap">
    <table>
      <thead><tr><th>Type</th><th>Amount</th><th>Coin</th><th>Status</th><th>Date</th></tr></thead>
      <tbody>
        <?php if(empty($recentTxns)): ?>
          <tr><td colspan="5" style="text-align:center;padding:24px;">No transactions yet</td></tr>
        <?php else: ?>
          <?php foreach($recentTxns as $tx): ?>
          <tr>
            <td><span class="badge badge-purple"><?= strtoupper(str_replace('_',' ',$tx['type'])) ?></span></td>
            <td style="color:var(--white);font-weight:600;"><?= money($tx['amount']) ?></td>
            <td><?= strtoupper($tx['coin_type']) ?></td>
            <td><span class="badge badge-<?= $tx['status']==='completed'?'green':($tx['status']==='pending'?'gold':'red') ?>"><?= strtoupper($tx['status']) ?></span></td>
            <td><?= date('d M, H:i', strtotime($tx['created_at'])) ?></td>
          </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
  <div style="text-align:right;margin-top:12px;"><a href="transactions.php" style="font-size:.82rem;color:var(--v2);">View All →</a></div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
const labels = <?= json_encode(array_map(fn($r) => date('d M', strtotime($r['dt'])), $chartData)) ?>;
const values = <?= json_encode(array_map(fn($r) => (float)$r['total'], $chartData)) ?>;

new Chart(document.getElementById('earningsChart'), {
  type: 'line',
  data: {
    labels: labels.length ? labels : ['No Data'],
    datasets: [{
      label: 'Earnings ($)',
      data: values.length ? values : [0],
      borderColor: '#A855F7',
      backgroundColor: 'rgba(168,85,247,.1)',
      fill: true,
      tension: .4,
      pointBackgroundColor: '#EC4899',
      pointBorderColor: '#EC4899',
      pointRadius: 4,
    }]
  },
  options: {
    responsive: true,
    plugins: { legend: { display: false } },
    scales: {
      x: { grid: { color: 'rgba(168,85,247,.06)' }, ticks: { color: '#9CA3AF', font: { size: 10 } } },
      y: { grid: { color: 'rgba(168,85,247,.06)' }, ticks: { color: '#9CA3AF', font: { size: 10 } } }
    }
  }
});
</script>

<?php include 'includes/footer.php'; ?>
