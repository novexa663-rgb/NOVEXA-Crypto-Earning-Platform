<?php
require_once 'config.php';
requireLogin();
$pageTitle = 'Deposit';
$user = getUser($_SESSION['user_id']);

$depositWallet = getSetting('deposit_wallet_usdt', 'YOUR_WALLET_ADDRESS');
$depositWalletSol = getSetting('deposit_wallet_sol', 'YOUR_SOL_ADDRESS');
$depositWalletBnb = getSetting('deposit_wallet_bnb', 'YOUR_BNB_ADDRESS');

if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $package = $_POST['package_type'] ?? '';
    $amount = $package === 'starter' ? 50 : ($package === 'upgrade' ? 100 : 0);
    $txnHash = trim($_POST['txn_hash'] ?? '');
    
    // Handle file upload
    $proofPath = '';
    if(isset($_FILES['payment_proof']) && $_FILES['payment_proof']['error'] === 0) {
        $ext = strtolower(pathinfo($_FILES['payment_proof']['name'], PATHINFO_EXTENSION));
        if(in_array($ext, ['jpg','jpeg','png','gif','pdf'])) {
            $filename = 'proof_' . $user['id'] . '_' . time() . '.' . $ext;
            move_uploaded_file($_FILES['payment_proof']['tmp_name'], 'uploads/payment_proof/' . $filename);
            $proofPath = $filename;
        }
    }
    
    if($amount > 0) {
        $stmt = $pdo->prepare("INSERT INTO deposits (user_id, package_type, amount, payment_proof, txn_hash, status) VALUES (?, ?, ?, ?, ?, 'pending')");
        $stmt->execute([$user['id'], $package, $amount, $proofPath, $txnHash]);
        addNotification($user['id'], 'Deposit Submitted', "Your $package package deposit of \$$amount is pending approval.", 'system');
        setFlash('success', 'Deposit submitted! Waiting for admin approval.');
        header('Location: deposit.php'); exit;
    } else {
        setFlash('error', 'Invalid package selected');
        header('Location: deposit.php'); exit;
    }
}

// Get deposit history
$stmt = $pdo->prepare("SELECT * FROM deposits WHERE user_id = ? ORDER BY created_at DESC");
$stmt->execute([$user['id']]); $deposits = $stmt->fetchAll(PDO::FETCH_ASSOC);

include 'includes/header.php';
?>

<div class="grid-2">
  <!-- DEPOSIT FORM -->
  <div class="card">
    <div class="card-title">💳 Make a Deposit</div>
    <form method="POST" enctype="multipart/form-data">
      <div class="form-group">
        <label class="form-label">Select Package</label>
        <select name="package_type" class="form-input" id="pkgSelect" onchange="updateWallet()">
          <option value="">— Choose Package —</option>
          <option value="starter" <?= isset($_GET['upgrade'])?'':'selected' ?>>$50 Starter Package</option>
          <option value="upgrade" <?= isset($_GET['upgrade'])?'selected':'' ?>>$100 Upgrade Package (2X ROI)</option>
        </select>
      </div>
      
      <div id="walletInfo" style="background:rgba(168,85,247,.05);border:1px solid var(--border);padding:16px;margin-bottom:16px;">
        <div class="form-label" style="margin-bottom:10px;">Send Payment To:</div>
        <div style="margin-bottom:12px;">
          <div style="font-size:.7rem;color:var(--text);margin-bottom:4px;">USDT (BEP20):</div>
          <div class="copy-wrap">
            <input type="text" class="form-input" value="<?= $depositWallet ?>" readonly style="font-size:.75rem;"/>
            <button type="button" class="copy-btn" onclick="copyText('<?= $depositWallet ?>')">COPY</button>
          </div>
        </div>
        <div style="margin-bottom:12px;">
          <div style="font-size:.7rem;color:var(--text);margin-bottom:4px;">SOL:</div>
          <div class="copy-wrap">
            <input type="text" class="form-input" value="<?= $depositWalletSol ?>" readonly style="font-size:.75rem;"/>
            <button type="button" class="copy-btn" onclick="copyText('<?= $depositWalletSol ?>')">COPY</button>
          </div>
        </div>
        <div>
          <div style="font-size:.7rem;color:var(--text);margin-bottom:4px;">BNB (BEP20):</div>
          <div class="copy-wrap">
            <input type="text" class="form-input" value="<?= $depositWalletBnb ?>" readonly style="font-size:.75rem;"/>
            <button type="button" class="copy-btn" onclick="copyText('<?= $depositWalletBnb ?>')">COPY</button>
          </div>
        </div>
      </div>
      
      <div class="form-group">
        <label class="form-label">Transaction Hash</label>
        <input type="text" name="txn_hash" class="form-input" placeholder="Paste your transaction hash"/>
      </div>
      
      <div class="form-group">
        <label class="form-label">Upload Payment Proof</label>
        <input type="file" name="payment_proof" class="form-input" accept="image/*,.pdf"/>
      </div>
      
      <button type="submit" class="btn btn-primary btn-block"><span>SUBMIT DEPOSIT →</span></button>
    </form>
  </div>
  
  <!-- PACKAGE INFO -->
  <div>
    <div class="card">
      <div class="card-title">⭐ Starter — $50</div>
      <ul style="list-style:none;display:flex;flex-direction:column;gap:8px;">
        <li style="font-size:.85rem;">◆ $25 Solana Meme Coin</li>
        <li style="font-size:.85rem;">◆ $25 BNB Coin</li>
        <li style="font-size:.85rem;">◆ Instant Credit</li>
        <li style="font-size:.85rem;">◆ 10% Direct Referral</li>
        <li style="font-size:.85rem;">◆ Binary Income Eligible</li>
        <li style="font-size:.85rem;">◆ Payout: 50% SOL + 50% BNB</li>
      </ul>
    </div>
    <div class="card" style="border-color:var(--v2);">
      <div class="card-title" style="color:var(--pink);">💎 Upgrade — $100</div>
      <ul style="list-style:none;display:flex;flex-direction:column;gap:8px;">
        <li style="font-size:.85rem;">◆ 2X ROI in 100 Days ($200)</li>
        <li style="font-size:.85rem;">◆ Daily ROI Credits</li>
        <li style="font-size:.85rem;">◆ 10% Direct Referral</li>
        <li style="font-size:.85rem;">◆ All Bonuses Active</li>
        <li style="font-size:.85rem;">◆ Payout: 80% USDT + 20% SOL</li>
      </ul>
    </div>
  </div>
</div>

<!-- DEPOSIT HISTORY -->
<div class="card">
  <div class="card-title">📋 Deposit History</div>
  <div class="table-wrap">
    <table>
      <thead><tr><th>Package</th><th>Amount</th><th>TXN Hash</th><th>Status</th><th>Date</th></tr></thead>
      <tbody>
        <?php if(empty($deposits)): ?>
          <tr><td colspan="5" style="text-align:center;padding:24px;">No deposits yet</td></tr>
        <?php else: ?>
          <?php foreach($deposits as $d): ?>
          <tr>
            <td><span class="badge badge-purple"><?= strtoupper($d['package_type']) ?></span></td>
            <td style="color:var(--white);font-weight:600;"><?= money($d['amount']) ?></td>
            <td style="font-family:'JetBrains Mono',monospace;font-size:.72rem;"><?= $d['txn_hash'] ? substr($d['txn_hash'],0,16).'...' : '-' ?></td>
            <td><span class="badge badge-<?= $d['status']==='approved'?'green':($d['status']==='pending'?'gold':'red') ?>"><?= strtoupper($d['status']) ?></span></td>
            <td><?= date('d M Y, H:i', strtotime($d['created_at'])) ?></td>
          </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php include 'includes/footer.php'; ?>
