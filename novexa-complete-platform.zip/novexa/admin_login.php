<?php
require_once 'config.php';
if(isset($_SESSION['admin_id'])) { header('Location: admin.php'); exit; }

$error = '';
if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $stmt = $pdo->prepare("SELECT * FROM admin WHERE username = ?");
    $stmt->execute([$username]);
    $admin = $stmt->fetch(PDO::FETCH_ASSOC);
    if($admin && password_verify($password, $admin['password'])) {
        $_SESSION['admin_id'] = $admin['id'];
        $_SESSION['admin_role'] = $admin['role'];
        header('Location: admin.php'); exit;
    } else { $error = 'Invalid credentials'; }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>Admin Login — NOVEXA</title>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=DM+Sans:wght@400;500&family=JetBrains+Mono:wght@400;700&display=swap" rel="stylesheet"/>
<style>
:root{--v:#7C3AED;--v2:#A855F7;--pink:#EC4899;--bg:#020008;--border:rgba(168,85,247,.15);--text:#9CA3AF;--white:#F9FAFB;}
*{margin:0;padding:0;box-sizing:border-box;}
body{background:var(--bg);color:var(--text);font-family:'DM Sans',sans-serif;min-height:100vh;display:flex;align-items:center;justify-content:center;}
.auth-card{width:100%;max-width:400px;background:rgba(255,255,255,.02);border:1px solid var(--border);padding:48px 40px;position:relative;}
.auth-card::before{content:'';position:absolute;top:0;left:0;right:0;height:2px;background:linear-gradient(90deg,var(--pink),var(--v2));}
.logo{font-family:'Syne',sans-serif;font-size:1.4rem;font-weight:800;letter-spacing:5px;text-align:center;color:var(--pink);margin-bottom:6px;}
.tagline{text-align:center;font-family:'JetBrains Mono',monospace;font-size:.6rem;letter-spacing:3px;color:var(--text);margin-bottom:32px;}
.form-group{margin-bottom:18px;}
.form-label{display:block;font-family:'JetBrains Mono',monospace;font-size:.62rem;font-weight:700;letter-spacing:2px;text-transform:uppercase;color:var(--text);margin-bottom:6px;}
.form-input{width:100%;padding:13px 16px;background:rgba(255,255,255,.03);border:1px solid var(--border);color:var(--white);font-family:'DM Sans',sans-serif;font-size:.88rem;outline:none;}
.form-input:focus{border-color:var(--pink);}
.btn{width:100%;padding:14px;background:linear-gradient(135deg,var(--pink),var(--v2));border:none;color:#fff;font-family:'Syne',sans-serif;font-size:.85rem;font-weight:700;letter-spacing:2px;cursor:pointer;clip-path:polygon(8px 0,100% 0,calc(100% - 8px) 100%,0 100%);}
.error{background:rgba(239,68,68,.08);border-left:3px solid #EF4444;padding:12px;color:#EF4444;font-size:.83rem;margin-bottom:16px;}
</style>
</head>
<body>
<div class="auth-card">
  <div class="logo">🛡️ ADMIN</div>
  <div class="tagline">◆ NOVEXA CONTROL PANEL ◆</div>
  <?php if($error): ?><div class="error"><?= $error ?></div><?php endif; ?>
  <form method="POST">
    <div class="form-group"><label class="form-label">Username</label><input type="text" name="username" class="form-input" required/></div>
    <div class="form-group"><label class="form-label">Password</label><input type="password" name="password" class="form-input" required/></div>
    <button type="submit" class="btn">ADMIN LOGIN →</button>
  </form>
</div>
</body>
</html>
