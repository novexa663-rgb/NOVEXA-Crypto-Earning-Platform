<?php
require_once 'config.php';
requireLogin();
$pageTitle = 'Wallet';
$user = getUser($_SESSION['user_id']);

$stmt = $pdo->prepare("SELECT * FROM wallet_balances WHERE user_id = ?");
$stmt->execute([$user['id']]);
$wallet = $stmt->fetch(PDO::FETCH_ASSOC);
if(!$wallet) { $wallet = ['usdt_balance'=>0,'sol_balance'=>0,'bnb_balance'=>0]; }

$stmt = $pdo->prepare("SELECT * FROM transactions WHERE user_id = ? ORDER BY created_at DESC LIMIT 20");
$stmt->execute([$user['id']]); $txns = $stmt->fetchAll(PDO::FETCH_ASSOC);

include 'includes/header.php';
?>

<!-- WALLET BALANCES -->
<div class="stat-grid">
  <div class="stat-card purple">
    <div class="stat-label">Total Balance</div>
    <div class="stat-value"><?= money($user['total_balance']) ?></div>
    <div class="stat-sub">Combined balance</div>
  </div>
  <div class="stat-card cyan">
    <div class="stat-label">USDT (BEP20)</div>
    <div class="stat-value"><?= number_format($wallet['usdt_balance'],4) ?></div>
    <div class="stat-sub">Tether BEP20</div>
  </div>
  <div class="stat-card pink">
    <div class="stat-label">SOL Balance</div>
    <div class="stat-value"><?= number_format($wallet['sol_balance'],4) ?></div>
    <div class="stat-sub">Solana</div>
  </div>
  <div class="stat-card gold">
    <div class="stat-label">BNB Balance</div>
    <div class="stat-value"><?= number_format($wallet['bnb_balance'],4) ?></div>
    <div class="stat-sub">Binance Coin</div>
  </div>
</div>

<!-- QUICK ACTIONS -->
<div class="card">
  <div class="card-title">⚡ Wallet Actions</div>
  <div style="display:flex;gap:12px;flex-wrap:wrap;">
    <a href="deposit.php" class="btn btn-primary"><span>💳 DEPOSIT</span></a>
    <a href="withdraw.php" class="btn btn-pink"><span>🏧 WITHDRAW</span></a>
  </div>
</div>

<!-- WALLET ADDRESSES -->
<div class="card">
  <div class="card-title">📍 Your Wallet Addresses</div>
  <div class="form-group">
    <label class="form-label">USDT BEP20 Address</label>
    <div class="copy-wrap">
      <input type="text" class="form-input" value="<?= htmlspecialchars($user['wallet_address_usdt']) ?>" readonly/>
      <button class="copy-btn" onclick="copyText('<?= htmlspecialchars($user['wallet_address_usdt']) ?>')">COPY</button>
    </div>
  </div>
  <div class="form-group">
    <label class="form-label">SOL Address</label>
    <div class="copy-wrap">
      <input type="text" class="form-input" value="<?= htmlspecialchars($user['wallet_address_sol']) ?>" readonly/>
      <button class="copy-btn" onclick="copyText('<?= htmlspecialchars($user['wallet_address_sol']) ?>')">COPY</button>
    </div>
  </div>
  <div class="form-group">
    <label class="form-label">BNB Address</label>
    <div class="copy-wrap">
      <input type="text" class="form-input" value="<?= htmlspecialchars($user['wallet_address_bnb']) ?>" readonly/>
      <button class="copy-btn" onclick="copyText('<?= htmlspecialchars($user['wallet_address_bnb']) ?>')">COPY</button>
    </div>
  </div>
  <a href="profile.php" style="font-size:.82rem;color:var(--v2);">Update addresses in Profile →</a>
</div>

<!-- TRANSACTION HISTORY -->
<div class="card">
  <div class="card-title">📋 Transaction History</div>
  <div class="table-wrap">
    <table>
      <thead><tr><th>Type</th><th>Amount</th><th>Coin</th><th>Description</th><th>Date</th></tr></thead>
      <tbody>
        <?php if(empty($txns)): ?>
          <tr><td colspan="5" style="text-align:center;padding:24px;">No transactions yet</td></tr>
        <?php else: ?>
          <?php foreach($txns as $tx): ?>
          <tr>
            <td><span class="badge badge-purple"><?= strtoupper(str_replace('_',' ',$tx['type'])) ?></span></td>
            <td style="color:var(--white);font-weight:600;"><?= money($tx['amount']) ?></td>
            <td><?= strtoupper($tx['coin_type']) ?></td>
            <td><?= htmlspecialchars($tx['description'] ?: '-') ?></td>
            <td><?= date('d M, H:i', strtotime($tx['created_at'])) ?></td>
          </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php include 'includes/footer.php'; ?>
