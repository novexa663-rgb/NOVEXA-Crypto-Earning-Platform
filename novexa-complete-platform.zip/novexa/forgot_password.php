<?php
require_once 'config.php';
$msg = '';
if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $stmt = $pdo->prepare("SELECT id, username FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $u = $stmt->fetch(PDO::FETCH_ASSOC);
    // In production: send email with reset link. For now, show message.
    $msg = 'If an account exists with this email, a password reset link has been sent. Please check your inbox.';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>Forgot Password — NOVEXA</title>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=DM+Sans:wght@400;500&family=JetBrains+Mono:wght@400;700&display=swap" rel="stylesheet"/>
<style>
:root{--v:#7C3AED;--v2:#A855F7;--pink:#EC4899;--bg:#020008;--border:rgba(168,85,247,.15);--text:#9CA3AF;--white:#F9FAFB;--green:#10B981;}
*{margin:0;padding:0;box-sizing:border-box;}
body{background:var(--bg);color:var(--text);font-family:'DM Sans',sans-serif;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px;}
.auth-card{width:100%;max-width:420px;background:rgba(255,255,255,.02);border:1px solid var(--border);padding:48px 40px;position:relative;}
.auth-card::before{content:'';position:absolute;top:0;left:0;right:0;height:2px;background:linear-gradient(90deg,var(--v),var(--pink));}
.logo{font-family:'Syne',sans-serif;font-size:1.6rem;font-weight:800;letter-spacing:5px;text-align:center;background:linear-gradient(135deg,var(--v2),var(--pink));-webkit-background-clip:text;background-clip:text;color:transparent;margin-bottom:8px;}
.tagline{text-align:center;font-family:'JetBrains Mono',monospace;font-size:.6rem;letter-spacing:3px;color:var(--text);margin-bottom:32px;}
.form-group{margin-bottom:18px;}
.form-label{display:block;font-family:'JetBrains Mono',monospace;font-size:.62rem;font-weight:700;letter-spacing:2px;text-transform:uppercase;color:var(--text);margin-bottom:6px;}
.form-input{width:100%;padding:13px 16px;background:rgba(255,255,255,.03);border:1px solid var(--border);color:var(--white);font-family:'DM Sans',sans-serif;font-size:.88rem;outline:none;}
.form-input:focus{border-color:var(--v2);}
.btn{width:100%;padding:14px;background:linear-gradient(135deg,var(--v),var(--v2));border:none;color:#fff;font-family:'Syne',sans-serif;font-size:.85rem;font-weight:700;letter-spacing:2px;cursor:pointer;clip-path:polygon(8px 0,100% 0,calc(100% - 8px) 100%,0 100%);}
.msg{background:rgba(16,185,129,.08);border-left:3px solid var(--green);padding:12px;color:var(--green);font-size:.83rem;margin-bottom:16px;}
.links{text-align:center;margin-top:18px;font-size:.82rem;}
.links a{color:var(--v2);text-decoration:none;}
</style>
</head>
<body>
<div class="auth-card">
  <div class="logo">NOVEXA</div>
  <div class="tagline">◆ RESET PASSWORD ◆</div>
  <?php if($msg): ?><div class="msg"><?= $msg ?></div><?php endif; ?>
  <form method="POST">
    <div class="form-group">
      <label class="form-label">Email Address</label>
      <input type="email" name="email" class="form-input" placeholder="Enter your email" required/>
    </div>
    <button type="submit" class="btn">RESET PASSWORD →</button>
  </form>
  <div class="links"><a href="login.php">← Back to Login</a></div>
</div>
</body>
</html>
