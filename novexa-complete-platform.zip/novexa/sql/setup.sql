-- NOVEXA Complete Database Schema
-- Run this on VPS: mysql -u root -p novexa_mlm < setup.sql

-- Drop existing tables if needed
SET FOREIGN_KEY_CHECKS = 0;

-- 1. USERS TABLE (upgraded)
DROP TABLE IF EXISTS users;
CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(100) NOT NULL,
  username VARCHAR(50) UNIQUE NOT NULL,
  email VARCHAR(100) UNIQUE NOT NULL,
  mobile VARCHAR(20),
  password VARCHAR(255) NOT NULL,
  sponsor_id INT DEFAULT NULL,
  referral_code VARCHAR(20) UNIQUE NOT NULL,
  wallet_address_usdt VARCHAR(255) DEFAULT '',
  wallet_address_sol VARCHAR(255) DEFAULT '',
  wallet_address_bnb VARCHAR(255) DEFAULT '',
  active_package ENUM('none','starter','upgrade') DEFAULT 'none',
  package_amount DECIMAL(10,2) DEFAULT 0,
  package_date DATETIME DEFAULT NULL,
  total_balance DECIMAL(12,2) DEFAULT 0,
  roi_balance DECIMAL(12,2) DEFAULT 0,
  referral_balance DECIMAL(12,2) DEFAULT 0,
  binary_balance DECIMAL(12,2) DEFAULT 0,
  total_withdrawn DECIMAL(12,2) DEFAULT 0,
  binary_left_vol DECIMAL(12,2) DEFAULT 0,
  binary_right_vol DECIMAL(12,2) DEFAULT 0,
  binary_carry_left DECIMAL(12,2) DEFAULT 0,
  binary_carry_right DECIMAL(12,2) DEFAULT 0,
  binary_position ENUM('left','right') DEFAULT NULL,
  binary_parent_id INT DEFAULT NULL,
  rank_level INT DEFAULT 0,
  kyc_status ENUM('pending','submitted','verified','rejected') DEFAULT 'pending',
  kyc_document VARCHAR(255) DEFAULT '',
  profile_pic VARCHAR(255) DEFAULT '',
  two_fa_enabled TINYINT(1) DEFAULT 0,
  two_fa_secret VARCHAR(255) DEFAULT '',
  status ENUM('active','blocked','inactive') DEFAULT 'active',
  last_login DATETIME DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 2. ADMIN TABLE (upgraded)
DROP TABLE IF EXISTS admin;
CREATE TABLE admin (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  email VARCHAR(100) DEFAULT '',
  role ENUM('superadmin','admin','moderator') DEFAULT 'admin',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Insert default admin
INSERT INTO admin (username, password, email, role) VALUES 
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin@novexa.org.in', 'superadmin');

-- 3. DEPOSITS TABLE
DROP TABLE IF EXISTS deposits;
CREATE TABLE deposits (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  package_type ENUM('starter','upgrade') NOT NULL,
  amount DECIMAL(10,2) NOT NULL,
  payment_proof VARCHAR(255) DEFAULT '',
  wallet_used VARCHAR(255) DEFAULT '',
  txn_hash VARCHAR(255) DEFAULT '',
  status ENUM('pending','approved','rejected') DEFAULT 'pending',
  admin_note TEXT DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE=InnoDB;

-- 4. WITHDRAWALS TABLE (upgraded)
DROP TABLE IF EXISTS withdrawals;
CREATE TABLE withdrawals (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  amount DECIMAL(10,2) NOT NULL,
  coin_type ENUM('usdt','sol','bnb') NOT NULL,
  wallet_address VARCHAR(255) NOT NULL,
  service_charge DECIMAL(10,2) DEFAULT 0,
  net_amount DECIMAL(10,2) DEFAULT 0,
  txn_hash VARCHAR(255) DEFAULT '',
  status ENUM('pending','approved','rejected','processing') DEFAULT 'pending',
  admin_note TEXT DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE=InnoDB;

-- 5. WALLET BALANCES TABLE
DROP TABLE IF EXISTS wallet_balances;
CREATE TABLE wallet_balances (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNIQUE NOT NULL,
  usdt_balance DECIMAL(12,4) DEFAULT 0,
  sol_balance DECIMAL(12,4) DEFAULT 0,
  bnb_balance DECIMAL(12,4) DEFAULT 0,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE=InnoDB;

-- 6. INCOME TABLE (upgraded)
DROP TABLE IF EXISTS income;
CREATE TABLE income (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  type ENUM('roi','referral','binary','direct_sponsor','rank_reward','bonus') NOT NULL,
  amount DECIMAL(10,2) NOT NULL,
  from_user_id INT DEFAULT NULL,
  description TEXT DEFAULT NULL,
  status ENUM('credited','pending','cancelled') DEFAULT 'credited',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE=InnoDB;

-- 7. ROI HISTORY TABLE
DROP TABLE IF EXISTS roi_history;
CREATE TABLE roi_history (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  day_number INT NOT NULL,
  daily_amount DECIMAL(10,2) NOT NULL,
  total_released DECIMAL(10,2) DEFAULT 0,
  total_remaining DECIMAL(10,2) DEFAULT 0,
  status ENUM('released','pending','completed') DEFAULT 'pending',
  release_date DATE NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE=InnoDB;

-- 8. BINARY TREE TABLE
DROP TABLE IF EXISTS binary_tree;
CREATE TABLE binary_tree (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNIQUE NOT NULL,
  parent_id INT DEFAULT NULL,
  position ENUM('left','right') DEFAULT NULL,
  left_child_id INT DEFAULT NULL,
  right_child_id INT DEFAULT NULL,
  left_volume DECIMAL(12,2) DEFAULT 0,
  right_volume DECIMAL(12,2) DEFAULT 0,
  carry_left DECIMAL(12,2) DEFAULT 0,
  carry_right DECIMAL(12,2) DEFAULT 0,
  total_left_members INT DEFAULT 0,
  total_right_members INT DEFAULT 0,
  matching_income DECIMAL(12,2) DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE=InnoDB;

-- 9. REFERRALS TABLE
DROP TABLE IF EXISTS referrals;
CREATE TABLE referrals (
  id INT AUTO_INCREMENT PRIMARY KEY,
  sponsor_id INT NOT NULL,
  referred_id INT NOT NULL,
  level INT DEFAULT 1,
  commission DECIMAL(10,2) DEFAULT 0,
  status ENUM('active','inactive') DEFAULT 'active',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (sponsor_id) REFERENCES users(id),
  FOREIGN KEY (referred_id) REFERENCES users(id)
) ENGINE=InnoDB;

-- 10. TRANSACTIONS TABLE
DROP TABLE IF EXISTS transactions;
CREATE TABLE transactions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  type ENUM('deposit','withdrawal','roi_credit','referral_credit','binary_credit','direct_sponsor','bonus','transfer','service_charge') NOT NULL,
  amount DECIMAL(10,2) NOT NULL,
  balance_after DECIMAL(12,2) DEFAULT 0,
  coin_type ENUM('usdt','sol','bnb','internal') DEFAULT 'internal',
  description TEXT DEFAULT NULL,
  reference_id INT DEFAULT NULL,
  status ENUM('completed','pending','failed') DEFAULT 'completed',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE=InnoDB;

-- 11. SUPPORT TICKETS TABLE
DROP TABLE IF EXISTS support_tickets;
CREATE TABLE support_tickets (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  subject VARCHAR(255) NOT NULL,
  message TEXT NOT NULL,
  priority ENUM('low','medium','high','urgent') DEFAULT 'medium',
  status ENUM('open','in_progress','resolved','closed') DEFAULT 'open',
  admin_reply TEXT DEFAULT NULL,
  replied_at DATETIME DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE=InnoDB;

-- 12. ANNOUNCEMENTS TABLE
DROP TABLE IF EXISTS announcements;
CREATE TABLE announcements (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  message TEXT NOT NULL,
  type ENUM('info','warning','update','promotion') DEFAULT 'info',
  display_type ENUM('scrollbar','popup','notification') DEFAULT 'scrollbar',
  target ENUM('all','starter','upgrade','specific') DEFAULT 'all',
  target_users TEXT DEFAULT NULL,
  priority INT DEFAULT 0,
  is_pinned TINYINT(1) DEFAULT 0,
  is_active TINYINT(1) DEFAULT 1,
  start_date DATETIME DEFAULT NULL,
  end_date DATETIME DEFAULT NULL,
  created_by INT DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 13. NOTIFICATIONS TABLE
DROP TABLE IF EXISTS notifications;
CREATE TABLE notifications (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  title VARCHAR(255) NOT NULL,
  message TEXT NOT NULL,
  type ENUM('income','withdrawal','system','announcement','security') DEFAULT 'system',
  is_read TINYINT(1) DEFAULT 0,
  link VARCHAR(255) DEFAULT '',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE=InnoDB;

-- 14. RANKS TABLE
DROP TABLE IF EXISTS ranks;
CREATE TABLE ranks (
  id INT AUTO_INCREMENT PRIMARY KEY,
  rank_name VARCHAR(50) NOT NULL,
  rank_level INT UNIQUE NOT NULL,
  required_direct INT DEFAULT 0,
  required_team INT DEFAULT 0,
  required_business DECIMAL(12,2) DEFAULT 0,
  reward_amount DECIMAL(10,2) DEFAULT 0,
  reward_description TEXT DEFAULT NULL,
  icon VARCHAR(50) DEFAULT '⭐',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Insert default ranks
INSERT INTO ranks (rank_name, rank_level, required_direct, required_team, required_business, reward_amount, icon) VALUES
('Bronze', 1, 5, 20, 1000, 25, '🥉'),
('Silver', 2, 10, 50, 5000, 100, '🥈'),
('Gold', 3, 20, 100, 15000, 300, '🥇'),
('Platinum', 4, 35, 250, 50000, 1000, '💎'),
('Diamond', 5, 50, 500, 100000, 3000, '👑');

-- 15. SETTINGS TABLE
DROP TABLE IF EXISTS settings;
CREATE TABLE settings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  setting_key VARCHAR(100) UNIQUE NOT NULL,
  setting_value TEXT NOT NULL,
  description VARCHAR(255) DEFAULT '',
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Insert default settings
INSERT INTO settings (setting_key, setting_value, description) VALUES
('site_name', 'NOVEXA', 'Platform name'),
('roi_daily_percent', '2', 'Daily ROI percentage for upgrade package'),
('roi_total_days', '100', 'Total ROI days'),
('referral_percent', '10', 'Direct referral commission percent'),
('binary_percent', '10', 'Binary matching income percent'),
('binary_daily_cap', '100', 'Binary daily cap in USD'),
('min_withdrawal', '10', 'Minimum withdrawal amount'),
('service_charge', '10', 'Withdrawal service charge percent'),
('starter_sol_percent', '50', 'Starter package SOL payout percent'),
('starter_bnb_percent', '50', 'Starter package BNB payout percent'),
('upgrade_usdt_percent', '80', 'Upgrade package USDT payout percent'),
('upgrade_sol_percent', '20', 'Upgrade package SOL payout percent'),
('deposit_wallet_usdt', 'YOUR_USDT_WALLET_ADDRESS', 'Admin USDT wallet for deposits'),
('deposit_wallet_sol', 'YOUR_SOL_WALLET_ADDRESS', 'Admin SOL wallet for deposits'),
('deposit_wallet_bnb', 'YOUR_BNB_WALLET_ADDRESS', 'Admin BNB wallet for deposits'),
('telegram_link', 'https://t.me/novexa', 'Telegram group link'),
('withdrawal_enabled', '1', 'Enable/disable withdrawals'),
('registration_enabled', '1', 'Enable/disable registration'),
('maintenance_mode', '0', 'Maintenance mode');

SET FOREIGN_KEY_CHECKS = 1;
