<?php
if(!isset($pageTitle)) $pageTitle = 'NOVEXA';
$user = isset($_SESSION['user_id']) ? getUser($_SESSION['user_id']) : null;
$unreadCount = $user ? getUnreadCount($user['id']) : 0;
$announcements = getActiveAnnouncements();
$scrollAnnouncements = array_filter($announcements, fn($a) => $a['display_type'] === 'scrollbar');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title><?= htmlspecialchars($pageTitle) ?> — NOVEXA</title>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@600;700;800&family=DM+Sans:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500;700&display=swap" rel="stylesheet"/>
<style>
:root{--v:#7C3AED;--v2:#A855F7;--v3:#C084FC;--pink:#EC4899;--gold:#F59E0B;--cyan:#06B6D4;--green:#10B981;--red:#EF4444;--bg:#020008;--bg2:#0A0018;--card:rgba(255,255,255,.03);--border:rgba(168,85,247,.15);--text:#9CA3AF;--white:#F9FAFB;}
*{margin:0;padding:0;box-sizing:border-box;}
body{background:var(--bg);color:var(--text);font-family:'DM Sans',sans-serif;min-height:100vh;}
a{color:var(--v2);text-decoration:none;}

/* LAYOUT */
.app-layout{display:flex;min-height:100vh;}
.sidebar{width:260px;background:var(--bg2);border-right:1px solid var(--border);padding:24px 0;position:fixed;top:0;left:0;bottom:0;overflow-y:auto;z-index:100;transition:transform .3s;}
.sidebar-logo{padding:0 24px 24px;font-family:'Syne',sans-serif;font-size:1.3rem;font-weight:800;letter-spacing:4px;background:linear-gradient(135deg,var(--v2),var(--pink));-webkit-background-clip:text;background-clip:text;color:transparent;border-bottom:1px solid var(--border);}
.sidebar-user{padding:20px 24px;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:12px;}
.sidebar-avatar{width:40px;height:40px;border-radius:50%;background:linear-gradient(135deg,var(--v),var(--v2));display:flex;align-items:center;justify-content:center;color:#fff;font-family:'Syne',sans-serif;font-weight:700;font-size:.9rem;}
.sidebar-uname{font-size:.85rem;color:var(--white);font-weight:600;}
.sidebar-pkg{font-family:'JetBrains Mono',monospace;font-size:.6rem;letter-spacing:1px;text-transform:uppercase;color:var(--v2);}

.sidebar-nav{padding:16px 0;}
.nav-group{margin-bottom:8px;}
.nav-group-label{padding:8px 24px;font-family:'JetBrains Mono',monospace;font-size:.58rem;font-weight:700;letter-spacing:2px;text-transform:uppercase;color:rgba(156,163,175,.4);}
.nav-item{display:flex;align-items:center;gap:12px;padding:10px 24px;color:var(--text);font-size:.85rem;font-weight:500;transition:all .2s;cursor:pointer;border-left:2px solid transparent;}
.nav-item:hover{background:rgba(168,85,247,.06);color:var(--white);border-left-color:var(--v2);}
.nav-item.active{background:rgba(168,85,247,.1);color:var(--white);border-left-color:var(--v2);}
.nav-item .icon{font-size:1rem;width:20px;text-align:center;}
.nav-item .badge{margin-left:auto;background:var(--pink);color:#fff;font-size:.6rem;font-weight:700;padding:2px 6px;border-radius:8px;font-family:'JetBrains Mono',monospace;}

.main-content{margin-left:260px;flex:1;min-height:100vh;}

/* TOPBAR */
.topbar{display:flex;align-items:center;justify-content:space-between;padding:16px 32px;border-bottom:1px solid var(--border);background:rgba(2,0,8,.8);backdrop-filter:blur(16px);position:sticky;top:0;z-index:50;}
.topbar-title{font-family:'Syne',sans-serif;font-size:1.1rem;font-weight:700;color:var(--white);}
.topbar-actions{display:flex;align-items:center;gap:16px;}
.notif-btn{position:relative;background:none;border:1px solid var(--border);color:var(--text);width:36px;height:36px;display:flex;align-items:center;justify-content:center;cursor:pointer;font-size:1rem;transition:all .2s;}
.notif-btn:hover{border-color:var(--v2);color:var(--white);}
.notif-btn .dot{position:absolute;top:6px;right:6px;width:7px;height:7px;background:var(--pink);border-radius:50%;display:none;}
.notif-btn .dot.show{display:block;}
.menu-toggle{display:none;background:none;border:1px solid var(--border);color:var(--white);width:36px;height:36px;align-items:center;justify-content:center;cursor:pointer;font-size:1.2rem;}

/* ANNOUNCEMENT BAR */
.announce-bar{background:linear-gradient(90deg,rgba(124,58,237,.15),rgba(236,72,153,.1));border-bottom:1px solid var(--border);padding:8px 0;overflow:hidden;}
.announce-track{display:flex;width:max-content;animation:annScroll 30s linear infinite;}
.announce-track:hover{animation-play-state:paused;}
.announce-item{display:flex;align-items:center;gap:8px;padding:0 40px;white-space:nowrap;font-size:.78rem;color:var(--v3);}
.announce-item .atype{font-family:'JetBrains Mono',monospace;font-size:.58rem;font-weight:700;letter-spacing:1px;padding:2px 6px;border-radius:2px;}
.atype.info{background:rgba(6,182,212,.15);color:var(--cyan);}
.atype.warning{background:rgba(245,158,11,.15);color:var(--gold);}
.atype.update{background:rgba(16,185,129,.15);color:var(--green);}
.atype.promotion{background:rgba(236,72,153,.15);color:var(--pink);}
@keyframes annScroll{0%{transform:translateX(0)}100%{transform:translateX(-50%)}}

/* PAGE CONTENT */
.page-content{padding:32px;}

/* CARDS */
.card{background:var(--card);border:1px solid var(--border);padding:24px;position:relative;overflow:hidden;margin-bottom:20px;}
.card::before{content:'';position:absolute;top:0;left:0;right:0;height:1px;background:linear-gradient(90deg,transparent,var(--v2),transparent);opacity:0;transition:opacity .3s;}
.card:hover::before{opacity:1;}
.card-title{font-family:'Syne',sans-serif;font-size:1rem;font-weight:700;color:var(--white);margin-bottom:16px;display:flex;align-items:center;gap:8px;}

/* STAT CARDS */
.stat-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:14px;margin-bottom:28px;}
.stat-card{background:var(--card);border:1px solid var(--border);padding:20px;position:relative;overflow:hidden;}
.stat-card::before{content:'';position:absolute;top:0;left:0;width:2px;height:100%;}
.stat-card.purple::before{background:linear-gradient(var(--v),var(--v2));}
.stat-card.pink::before{background:linear-gradient(var(--pink),var(--v2));}
.stat-card.gold::before{background:linear-gradient(var(--gold),var(--pink));}
.stat-card.cyan::before{background:linear-gradient(var(--cyan),var(--v2));}
.stat-card.green::before{background:linear-gradient(var(--green),var(--cyan));}
.stat-card.red::before{background:linear-gradient(var(--red),var(--pink));}
.stat-label{font-family:'JetBrains Mono',monospace;font-size:.6rem;font-weight:700;letter-spacing:2px;text-transform:uppercase;color:var(--text);margin-bottom:8px;}
.stat-value{font-family:'Syne',sans-serif;font-size:1.6rem;font-weight:800;color:var(--white);}
.stat-sub{font-size:.75rem;color:var(--text);margin-top:4px;}

/* BUTTONS */
.btn{padding:10px 24px;border:none;font-family:'Syne',sans-serif;font-size:.78rem;font-weight:700;letter-spacing:1px;cursor:pointer;transition:all .3s;display:inline-flex;align-items:center;gap:8px;}
.btn-primary{background:linear-gradient(135deg,var(--v),var(--v2));color:#fff;clip-path:polygon(6px 0,100% 0,calc(100% - 6px) 100%,0 100%);}
.btn-primary:hover{filter:brightness(1.15);}
.btn-secondary{background:transparent;border:1px solid var(--border);color:var(--white);clip-path:polygon(6px 0,100% 0,calc(100% - 6px) 100%,0 100%);}
.btn-secondary:hover{background:rgba(168,85,247,.1);border-color:var(--v2);}
.btn-pink{background:linear-gradient(135deg,var(--pink),var(--v2));color:#fff;clip-path:polygon(6px 0,100% 0,calc(100% - 6px) 100%,0 100%);}
.btn-sm{padding:6px 14px;font-size:.68rem;}
.btn-block{width:100%;justify-content:center;}
.btn-green{background:linear-gradient(135deg,var(--green),var(--cyan));color:#fff;clip-path:polygon(6px 0,100% 0,calc(100% - 6px) 100%,0 100%);}
.btn-red{background:linear-gradient(135deg,var(--red),var(--pink));color:#fff;clip-path:polygon(6px 0,100% 0,calc(100% - 6px) 100%,0 100%);}

/* FORMS */
.form-group{margin-bottom:16px;}
.form-label{display:block;font-family:'JetBrains Mono',monospace;font-size:.65rem;font-weight:700;letter-spacing:2px;text-transform:uppercase;color:var(--text);margin-bottom:6px;}
.form-input{width:100%;padding:12px 16px;background:rgba(255,255,255,.03);border:1px solid var(--border);color:var(--white);font-family:'DM Sans',sans-serif;font-size:.88rem;transition:border-color .2s;outline:none;}
.form-input:focus{border-color:var(--v2);background:rgba(168,85,247,.04);}
.form-input::placeholder{color:rgba(156,163,175,.4);}
select.form-input{cursor:pointer;appearance:none;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%239CA3AF' stroke-width='2'%3E%3Cpath d='M6 9l6 6 6-6'/%3E%3C/svg%3E");background-repeat:no-repeat;background-position:right 12px center;}
textarea.form-input{resize:vertical;min-height:80px;}

/* TABLES */
.table-wrap{overflow-x:auto;margin-top:12px;}
table{width:100%;border-collapse:collapse;}
th{font-family:'JetBrains Mono',monospace;font-size:.6rem;font-weight:700;letter-spacing:2px;text-transform:uppercase;color:var(--text);text-align:left;padding:12px 16px;border-bottom:1px solid var(--border);background:rgba(168,85,247,.04);}
td{padding:12px 16px;border-bottom:1px solid rgba(168,85,247,.06);font-size:.85rem;color:var(--text);}
tr:hover td{background:rgba(168,85,247,.03);}

/* BADGES */
.badge{display:inline-block;padding:3px 8px;font-family:'JetBrains Mono',monospace;font-size:.58rem;font-weight:700;letter-spacing:1px;border-radius:2px;}
.badge-green{background:rgba(16,185,129,.15);color:var(--green);}
.badge-red{background:rgba(239,68,68,.15);color:var(--red);}
.badge-gold{background:rgba(245,158,11,.15);color:var(--gold);}
.badge-purple{background:rgba(168,85,247,.15);color:var(--v2);}
.badge-cyan{background:rgba(6,182,212,.15);color:var(--cyan);}
.badge-pink{background:rgba(236,72,153,.15);color:var(--pink);}

/* FLASH MESSAGES */
.flash{padding:14px 20px;margin-bottom:20px;font-size:.85rem;border-left:3px solid;}
.flash-success{background:rgba(16,185,129,.08);border-color:var(--green);color:var(--green);}
.flash-error{background:rgba(239,68,68,.08);border-color:var(--red);color:var(--red);}
.flash-warning{background:rgba(245,158,11,.08);border-color:var(--gold);color:var(--gold);}
.flash-info{background:rgba(6,182,212,.08);border-color:var(--cyan);color:var(--cyan);}

/* TABS */
.tabs{display:flex;gap:0;border-bottom:1px solid var(--border);margin-bottom:24px;}
.tab{padding:12px 24px;font-family:'JetBrains Mono',monospace;font-size:.7rem;font-weight:700;letter-spacing:1px;color:var(--text);cursor:pointer;border-bottom:2px solid transparent;transition:all .2s;}
.tab:hover{color:var(--white);}
.tab.active{color:var(--v2);border-bottom-color:var(--v2);}

/* COPY BTN */
.copy-wrap{display:flex;gap:8px;align-items:center;}
.copy-wrap input{flex:1;}
.copy-btn{padding:12px 16px;background:rgba(168,85,247,.1);border:1px solid var(--border);color:var(--v2);cursor:pointer;font-size:.78rem;transition:all .2s;}
.copy-btn:hover{background:rgba(168,85,247,.2);}

/* POPUP MODAL */
.modal-overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,.7);backdrop-filter:blur(4px);z-index:200;align-items:center;justify-content:center;}
.modal-overlay.show{display:flex;}
.modal{background:var(--bg2);border:1px solid var(--border);padding:32px;max-width:480px;width:90%;max-height:80vh;overflow-y:auto;position:relative;}
.modal-close{position:absolute;top:12px;right:12px;background:none;border:none;color:var(--text);font-size:1.2rem;cursor:pointer;}
.modal-close:hover{color:var(--white);}

/* PROGRESS BAR */
.progress{height:4px;background:rgba(168,85,247,.1);overflow:hidden;margin-top:8px;}
.progress-bar{height:100%;transition:width .3s;}
.progress-bar.purple{background:linear-gradient(90deg,var(--v),var(--v2));}
.progress-bar.pink{background:linear-gradient(90deg,var(--pink),var(--v2));}
.progress-bar.green{background:linear-gradient(90deg,var(--green),var(--cyan));}

/* GRID HELPERS */
.grid-2{display:grid;grid-template-columns:1fr 1fr;gap:20px;}
.grid-3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:20px;}

/* MOBILE */
@media(max-width:768px){
  .sidebar{transform:translateX(-100%);}
  .sidebar.open{transform:translateX(0);}
  .main-content{margin-left:0;}
  .menu-toggle{display:flex;}
  .page-content{padding:20px;}
  .stat-grid{grid-template-columns:1fr 1fr;}
  .grid-2,.grid-3{grid-template-columns:1fr;}
  .topbar{padding:12px 16px;}
}
</style>
</head>
<body>
<div class="app-layout">

<!-- SIDEBAR -->
<aside class="sidebar" id="sidebar">
  <div class="sidebar-logo">NOVEXA</div>
  <?php if($user): ?>
  <div class="sidebar-user">
    <div class="sidebar-avatar"><?= strtoupper(substr($user['username'],0,1)) ?></div>
    <div>
      <div class="sidebar-uname"><?= htmlspecialchars($user['username']) ?></div>
      <div class="sidebar-pkg"><?= $user['active_package'] !== 'none' ? '◆ '.strtoupper($user['active_package']) : '◆ NO PACKAGE' ?></div>
    </div>
  </div>
  <?php endif; ?>
  <nav class="sidebar-nav">
    <div class="nav-group">
      <div class="nav-group-label">Main</div>
      <a href="dashboard.php" class="nav-item <?= $pageTitle=='Dashboard'?'active':'' ?>"><span class="icon">📊</span> Dashboard</a>
      <a href="wallet.php" class="nav-item <?= $pageTitle=='Wallet'?'active':'' ?>"><span class="icon">💰</span> Wallet</a>
      <a href="deposit.php" class="nav-item <?= $pageTitle=='Deposit'?'active':'' ?>"><span class="icon">💳</span> Deposit</a>
      <a href="withdraw.php" class="nav-item <?= $pageTitle=='Withdraw'?'active':'' ?>"><span class="icon">🏧</span> Withdraw</a>
    </div>
    <div class="nav-group">
      <div class="nav-group-label">Earnings</div>
      <a href="roi.php" class="nav-item <?= $pageTitle=='ROI'?'active':'' ?>"><span class="icon">📈</span> ROI Income</a>
      <a href="referral.php" class="nav-item <?= $pageTitle=='Referral'?'active':'' ?>"><span class="icon">👥</span> Referral</a>
      <a href="binary.php" class="nav-item <?= $pageTitle=='Binary'?'active':'' ?>"><span class="icon">🌳</span> Binary Tree</a>
    </div>
    <div class="nav-group">
      <div class="nav-group-label">Network</div>
      <a href="team.php" class="nav-item <?= $pageTitle=='Team'?'active':'' ?>"><span class="icon">👨‍👩‍👧‍👦</span> My Team</a>
      <a href="transactions.php" class="nav-item <?= $pageTitle=='Transactions'?'active':'' ?>"><span class="icon">📋</span> Transactions</a>
    </div>
    <div class="nav-group">
      <div class="nav-group-label">Account</div>
      <a href="profile.php" class="nav-item <?= $pageTitle=='Profile'?'active':'' ?>"><span class="icon">⚙️</span> Profile</a>
      <a href="support.php" class="nav-item <?= $pageTitle=='Support'?'active':'' ?>"><span class="icon">🎧</span> Support</a>
      <a href="logout.php" class="nav-item"><span class="icon">🚪</span> Logout</a>
    </div>
  </nav>
</aside>

<!-- MAIN -->
<div class="main-content">
  <!-- TOPBAR -->
  <div class="topbar">
    <div style="display:flex;align-items:center;gap:16px;">
      <button class="menu-toggle" onclick="document.getElementById('sidebar').classList.toggle('open')">☰</button>
      <div class="topbar-title"><?= htmlspecialchars($pageTitle) ?></div>
    </div>
    <div class="topbar-actions">
      <a href="notifications.php" class="notif-btn">🔔<span class="dot <?= $unreadCount > 0 ? 'show' : '' ?>"></span></a>
      <a href="profile.php" class="notif-btn">👤</a>
    </div>
  </div>

  <!-- ANNOUNCEMENT SCROLLBAR -->
  <?php if(!empty($scrollAnnouncements)): ?>
  <div class="announce-bar">
    <div class="announce-track">
      <?php foreach($scrollAnnouncements as $ann): ?>
        <?php $dup = $ann; // duplicate for seamless loop ?>
        <div class="announce-item">
          <span class="atype <?= $ann['type'] ?>"><?= strtoupper($ann['type']) ?></span>
          <?= htmlspecialchars($ann['title']) ?> — <?= htmlspecialchars($ann['message']) ?>
        </div>
      <?php endforeach; ?>
      <?php foreach($scrollAnnouncements as $ann): ?>
        <div class="announce-item">
          <span class="atype <?= $ann['type'] ?>"><?= strtoupper($ann['type']) ?></span>
          <?= htmlspecialchars($ann['title']) ?> — <?= htmlspecialchars($ann['message']) ?>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
  <?php endif; ?>

  <!-- POPUP ANNOUNCEMENTS -->
  <?php 
  $popupAnns = array_filter($announcements, fn($a) => $a['display_type'] === 'popup');
  if(!empty($popupAnns)):
    $popup = array_values($popupAnns)[0];
  ?>
  <div class="modal-overlay show" id="annPopup">
    <div class="modal">
      <button class="modal-close" onclick="document.getElementById('annPopup').classList.remove('show')">&times;</button>
      <div style="margin-bottom:12px;"><span class="atype <?= $popup['type'] ?>"><?= strtoupper($popup['type']) ?></span></div>
      <h3 style="font-family:'Syne',sans-serif;color:var(--white);margin-bottom:12px;"><?= htmlspecialchars($popup['title']) ?></h3>
      <p style="font-size:.88rem;line-height:1.6;"><?= htmlspecialchars($popup['message']) ?></p>
      <button class="btn btn-primary" style="margin-top:20px;" onclick="document.getElementById('annPopup').classList.remove('show')"><span>GOT IT</span></button>
    </div>
  </div>
  <?php endif; ?>

  <!-- FLASH MESSAGE -->
  <?php $flash = getFlash(); if($flash): ?>
  <div style="padding:16px 32px 0;">
    <div class="flash flash-<?= $flash['type'] ?>"><?= htmlspecialchars($flash['message']) ?></div>
  </div>
  <?php endif; ?>

  <!-- PAGE CONTENT -->
  <div class="page-content">
