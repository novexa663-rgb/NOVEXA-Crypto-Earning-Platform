  </div><!-- /page-content -->
</div><!-- /main-content -->
</div><!-- /app-layout -->

<script>
// Close sidebar on outside click (mobile)
document.addEventListener('click', function(e) {
  const sb = document.getElementById('sidebar');
  const mt = document.querySelector('.menu-toggle');
  if(window.innerWidth <= 768 && sb.classList.contains('open') && !sb.contains(e.target) && !mt.contains(e.target)) {
    sb.classList.remove('open');
  }
});

// Copy to clipboard
function copyText(text) {
  navigator.clipboard.writeText(text).then(() => {
    const btn = event.target;
    btn.textContent = '✓ Copied!';
    setTimeout(() => btn.textContent = 'COPY', 2000);
  });
}
</script>
</body>
</html>
