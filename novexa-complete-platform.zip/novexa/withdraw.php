<?php
require_once 'config.php';
requireLogin();
$pageTitle = 'Withdraw';
$user = getUser($_SESSION['user_id']);
$minWithdraw = getSetting('min_withdrawal', 10);
$serviceCharge = getSetting('service_charge', 10);

if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $amount = floatval($_POST['amount'] ?? 0);
    $coinType = $_POST['coin_type'] ?? '';
    $walletAddr = trim($_POST['wallet_address'] ?? '');
    
    if($amount < $minWithdraw) {
        setFlash('error', "Minimum withdrawal is \$$minWithdraw");
    } elseif($amount > $user['total_balance']) {
        setFlash('error', 'Insufficient balance');
    } elseif(!in_array($coinType, ['usdt','sol','bnb'])) {
        setFlash('error', 'Select a valid coin');
    } elseif(empty($walletAddr)) {
        setFlash('error', 'Enter wallet address');
    } else {
        $charge = $amount * ($serviceCharge / 100);
        $netAmount = $amount - $charge;
        
        $stmt = $pdo->prepare("INSERT INTO withdrawals (user_id, amount, coin_type, wallet_address, service_charge, net_amount, status) VALUES (?, ?, ?, ?, ?, ?, 'pending')");
        $stmt->execute([$user['id'], $amount, $coinType, $walletAddr, $charge, $netAmount]);
        
        $pdo->prepare("UPDATE users SET total_balance = total_balance - ? WHERE id = ?")->execute([$amount, $user['id']]);
        addTransaction($user['id'], 'withdrawal', $amount, $coinType, "Withdrawal to $walletAddr");
        addNotification($user['id'], 'Withdrawal Submitted', "Your withdrawal of \$$amount is pending.", 'withdrawal');
        
        setFlash('success', "Withdrawal of \$$netAmount ($coinType) submitted! Service charge: \$$charge");
    }
    header('Location: withdraw.php'); exit;
}

$stmt = $pdo->prepare("SELECT * FROM withdrawals WHERE user_id = ? ORDER BY created_at DESC");
$stmt->execute([$user['id']]); $withdrawals = $stmt->fetchAll(PDO::FETCH_ASSOC);

include 'includes/header.php';
?>

<div class="grid-2">
  <div class="card">
    <div class="card-title">🏧 Request Withdrawal</div>
    <div class="stat-grid" style="margin-bottom:20px;">
      <div class="stat-card purple">
        <div class="stat-label">Available</div>
        <div class="stat-value"><?= money($user['total_balance']) ?></div>
      </div>
      <div class="stat-card pink">
        <div class="stat-label">Min Withdraw</div>
        <div class="stat-value"><?= money($minWithdraw) ?></div>
      </div>
    </div>
    
    <form method="POST">
      <div class="form-group">
        <label class="form-label">Select Coin</label>
        <select name="coin_type" class="form-input" required>
          <option value="">— Choose Coin —</option>
          <option value="usdt">USDT (BEP20)</option>
          <option value="sol">SOL (Solana)</option>
          <option value="bnb">BNB (BEP20)</option>
        </select>
      </div>
      <div class="form-group">
        <label class="form-label">Amount (USD)</label>
        <input type="number" name="amount" class="form-input" placeholder="Enter amount" step="0.01" min="<?= $minWithdraw ?>" id="wdAmount" oninput="calcCharge()"/>
      </div>
      <div class="form-group">
        <label class="form-label">Wallet Address</label>
        <input type="text" name="wallet_address" class="form-input" placeholder="Your wallet address" value="<?= htmlspecialchars($user['wallet_address_usdt']) ?>" required/>
      </div>
      
      <div style="background:rgba(168,85,247,.05);border:1px solid var(--border);padding:14px;margin-bottom:16px;">
        <div style="display:flex;justify-content:space-between;font-size:.83rem;margin-bottom:6px;">
          <span>Service Charge (<?= $serviceCharge ?>%)</span>
          <span style="color:var(--pink);" id="chargeDisplay">$0.00</span>
        </div>
        <div style="display:flex;justify-content:space-between;font-size:.9rem;font-weight:600;color:var(--white);">
          <span>You Receive</span>
          <span style="color:var(--green);" id="netDisplay">$0.00</span>
        </div>
      </div>
      
      <button type="submit" class="btn btn-pink btn-block"><span>SUBMIT WITHDRAWAL →</span></button>
    </form>
  </div>
  
  <div>
    <div class="card">
      <div class="card-title">ℹ️ Payout Rules</div>
      <div style="font-size:.85rem;line-height:1.8;">
        <strong style="color:var(--white);">$100 Upgrade:</strong><br/>
        ◆ 80% in USDT BEP20<br/>
        ◆ 20% in SOL<br/><br/>
        <strong style="color:var(--white);">$50 Starter:</strong><br/>
        ◆ 50% in SOL<br/>
        ◆ 50% in BNB<br/><br/>
        <strong style="color:var(--gold);">Service Charge:</strong> <?= $serviceCharge ?>%<br/>
        <strong style="color:var(--gold);">Min Withdrawal:</strong> $<?= $minWithdraw ?>
      </div>
    </div>
  </div>
</div>

<!-- HISTORY -->
<div class="card">
  <div class="card-title">📋 Withdrawal History</div>
  <div class="table-wrap">
    <table>
      <thead><tr><th>Amount</th><th>Charge</th><th>Net</th><th>Coin</th><th>Status</th><th>Date</th></tr></thead>
      <tbody>
        <?php if(empty($withdrawals)): ?>
          <tr><td colspan="6" style="text-align:center;padding:24px;">No withdrawals yet</td></tr>
        <?php else: foreach($withdrawals as $w): ?>
          <tr>
            <td style="color:var(--white);font-weight:600;"><?= money($w['amount']) ?></td>
            <td style="color:var(--pink);"><?= money($w['service_charge']) ?></td>
            <td style="color:var(--green);"><?= money($w['net_amount']) ?></td>
            <td><?= strtoupper($w['coin_type']) ?></td>
            <td><span class="badge badge-<?= $w['status']==='approved'?'green':($w['status']==='pending'?'gold':'red') ?>"><?= strtoupper($w['status']) ?></span></td>
            <td><?= date('d M, H:i', strtotime($w['created_at'])) ?></td>
          </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
</div>

<script>
function calcCharge(){
  const amt = parseFloat(document.getElementById('wdAmount').value)||0;
  const charge = amt * <?= $serviceCharge/100 ?>;
  document.getElementById('chargeDisplay').textContent = '$'+charge.toFixed(2);
  document.getElementById('netDisplay').textContent = '$'+(amt-charge).toFixed(2);
}
</script>

<?php include 'includes/footer.php'; ?>
