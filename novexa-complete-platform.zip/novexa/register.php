<?php
require_once 'config.php';
if(isLoggedIn()) { header('Location: dashboard.php'); exit; }

$error = ''; $success = '';
if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullname = trim($_POST['full_name'] ?? '');
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $mobile = trim($_POST['mobile'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';
    $sponsorCode = trim($_POST['sponsor_id'] ?? '');
    $wallet = trim($_POST['wallet_address'] ?? '');
    
    if($password !== $confirm) {
        $error = 'Passwords do not match';
    } elseif(strlen($password) < 6) {
        $error = 'Password must be at least 6 characters';
    } else {
        // Check duplicates
        $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
        $stmt->execute([$username, $email]);
        if($stmt->fetch()) {
            $error = 'Username or email already exists';
        } else {
            // Find sponsor
            $sponsorId = null;
            if($sponsorCode) {
                $stmt = $pdo->prepare("SELECT id FROM users WHERE referral_code = ?");
                $stmt->execute([$sponsorCode]);
                $sponsor = $stmt->fetch(PDO::FETCH_ASSOC);
                if($sponsor) { $sponsorId = $sponsor['id']; }
                else { $error = 'Invalid referral/sponsor code'; }
            }
            
            if(!$error) {
                $refCode = generateReferralCode();
                $hashedPass = password_hash($password, PASSWORD_DEFAULT);
                
                $stmt = $pdo->prepare("INSERT INTO users (full_name, username, email, mobile, password, sponsor_id, referral_code, wallet_address_usdt) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$fullname, $username, $email, $mobile, $hashedPass, $sponsorId, $refCode, $wallet]);
                
                $newUserId = $pdo->lastInsertId();
                
                // Create wallet balance record
                $pdo->prepare("INSERT INTO wallet_balances (user_id) VALUES (?)")->execute([$newUserId]);
                
                // Create binary tree record
                $pdo->prepare("INSERT INTO binary_tree (user_id, parent_id) VALUES (?, ?)")->execute([$newUserId, $sponsorId]);
                
                // Record referral
                if($sponsorId) {
                    $pdo->prepare("INSERT INTO referrals (sponsor_id, referred_id) VALUES (?, ?)")->execute([$sponsorId, $newUserId]);
                    addNotification($sponsorId, 'New Referral!', "$fullname joined using your referral code.", 'income');
                }
                
                $success = 'Account created! Your referral code: ' . $refCode;
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>Register — NOVEXA</title>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=DM+Sans:wght@400;500;600&family=JetBrains+Mono:wght@400;700&display=swap" rel="stylesheet"/>
<style>
:root{--v:#7C3AED;--v2:#A855F7;--v3:#C084FC;--pink:#EC4899;--bg:#020008;--border:rgba(168,85,247,.15);--text:#9CA3AF;--white:#F9FAFB;--green:#10B981;}
*{margin:0;padding:0;box-sizing:border-box;}
body{background:var(--bg);color:var(--text);font-family:'DM Sans',sans-serif;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px;}
.auth-card{width:100%;max-width:480px;background:rgba(255,255,255,.02);border:1px solid var(--border);padding:40px;position:relative;overflow:hidden;}
.auth-card::before{content:'';position:absolute;top:0;left:0;right:0;height:2px;background:linear-gradient(90deg,var(--v),var(--pink),var(--v2));}
.logo{font-family:'Syne',sans-serif;font-size:1.6rem;font-weight:800;letter-spacing:5px;text-align:center;background:linear-gradient(135deg,var(--v2),var(--pink));-webkit-background-clip:text;background-clip:text;color:transparent;margin-bottom:8px;}
.tagline{text-align:center;font-family:'JetBrains Mono',monospace;font-size:.6rem;letter-spacing:3px;color:var(--text);margin-bottom:32px;}
.form-group{margin-bottom:14px;}
.form-label{display:block;font-family:'JetBrains Mono',monospace;font-size:.62rem;font-weight:700;letter-spacing:2px;text-transform:uppercase;color:var(--text);margin-bottom:5px;}
.form-input{width:100%;padding:12px 16px;background:rgba(255,255,255,.03);border:1px solid var(--border);color:var(--white);font-family:'DM Sans',sans-serif;font-size:.86rem;outline:none;transition:border-color .2s;}
.form-input:focus{border-color:var(--v2);}
.form-input::placeholder{color:rgba(156,163,175,.3);}
.grid-2{display:grid;grid-template-columns:1fr 1fr;gap:14px;}
.btn{width:100%;padding:14px;background:linear-gradient(135deg,var(--v),var(--v2));border:none;color:#fff;font-family:'Syne',sans-serif;font-size:.85rem;font-weight:700;letter-spacing:2px;cursor:pointer;clip-path:polygon(8px 0,100% 0,calc(100% - 8px) 100%,0 100%);margin-top:8px;transition:filter .2s;}
.btn:hover{filter:brightness(1.15);}
.links{text-align:center;margin-top:18px;font-size:.82rem;}
.links a{color:var(--v2);text-decoration:none;}
.links a:hover{color:var(--pink);}
.error{background:rgba(239,68,68,.08);border-left:3px solid #EF4444;padding:12px;color:#EF4444;font-size:.83rem;margin-bottom:16px;}
.success{background:rgba(16,185,129,.08);border-left:3px solid var(--green);padding:12px;color:var(--green);font-size:.83rem;margin-bottom:16px;}
.glow{position:fixed;width:300px;height:300px;border-radius:50%;background:radial-gradient(circle,rgba(124,58,237,.08),transparent 70%);pointer-events:none;}
@media(max-width:500px){.grid-2{grid-template-columns:1fr;}}
</style>
</head>
<body>
<div class="glow" style="top:10%;left:5%;"></div>
<div class="glow" style="bottom:10%;right:5%;background:radial-gradient(circle,rgba(236,72,153,.06),transparent 70%);"></div>

<div class="auth-card">
  <div class="logo">NOVEXA</div>
  <div class="tagline">◆ CREATE YOUR ACCOUNT ◆</div>
  
  <?php if($error): ?><div class="error"><?= $error ?></div><?php endif; ?>
  <?php if($success): ?><div class="success"><?= $success ?> <a href="login.php" style="color:var(--v2);">Login Now →</a></div><?php endif; ?>
  
  <form method="POST">
    <div class="form-group">
      <label class="form-label">Full Name</label>
      <input type="text" name="full_name" class="form-input" placeholder="Enter full name" required/>
    </div>
    <div class="grid-2">
      <div class="form-group">
        <label class="form-label">Username</label>
        <input type="text" name="username" class="form-input" placeholder="Choose username" required/>
      </div>
      <div class="form-group">
        <label class="form-label">Mobile Number</label>
        <input type="text" name="mobile" class="form-input" placeholder="+91 XXXXXXXX"/>
      </div>
    </div>
    <div class="form-group">
      <label class="form-label">Email Address</label>
      <input type="email" name="email" class="form-input" placeholder="you@email.com" required/>
    </div>
    <div class="grid-2">
      <div class="form-group">
        <label class="form-label">Password</label>
        <input type="password" name="password" class="form-input" placeholder="Min 6 characters" required/>
      </div>
      <div class="form-group">
        <label class="form-label">Confirm Password</label>
        <input type="password" name="confirm_password" class="form-input" placeholder="Confirm" required/>
      </div>
    </div>
    <div class="form-group">
      <label class="form-label">Sponsor / Referral Code</label>
      <input type="text" name="sponsor_id" class="form-input" placeholder="e.g. NVX3A8F2B (optional)"/>
    </div>
    <div class="form-group">
      <label class="form-label">Wallet Address (USDT BEP20)</label>
      <input type="text" name="wallet_address" class="form-input" placeholder="Your BEP20 wallet address"/>
    </div>
    <button type="submit" class="btn">CREATE ACCOUNT →</button>
  </form>
  
  <div class="links">Already have an account? <a href="login.php">Login →</a></div>
</div>
</body>
</html>
