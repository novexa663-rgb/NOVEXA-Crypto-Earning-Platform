<?php
require_once 'config.php';
requireLogin();
$pageTitle = 'Support';
$user = getUser($_SESSION['user_id']);
$telegramLink = getSetting('telegram_link', 'https://t.me/novexa');

if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $subject = trim($_POST['subject'] ?? '');
    $message = trim($_POST['message'] ?? '');
    $priority = $_POST['priority'] ?? 'medium';
    
    if($subject && $message) {
        $stmt = $pdo->prepare("INSERT INTO support_tickets (user_id, subject, message, priority) VALUES (?, ?, ?, ?)");
        $stmt->execute([$user['id'], $subject, $message, $priority]);
        setFlash('success', 'Support ticket created! We will respond soon.');
        header('Location: support.php'); exit;
    }
}

$stmt = $pdo->prepare("SELECT * FROM support_tickets WHERE user_id = ? ORDER BY created_at DESC");
$stmt->execute([$user['id']]); $tickets = $stmt->fetchAll(PDO::FETCH_ASSOC);

include 'includes/header.php';
?>

<div class="grid-2">
  <div class="card">
    <div class="card-title">🎫 Create New Ticket</div>
    <form method="POST">
      <div class="form-group">
        <label class="form-label">Subject</label>
        <input type="text" name="subject" class="form-input" placeholder="Brief description of your issue" required/>
      </div>
      <div class="form-group">
        <label class="form-label">Priority</label>
        <select name="priority" class="form-input">
          <option value="low">Low</option>
          <option value="medium" selected>Medium</option>
          <option value="high">High</option>
          <option value="urgent">Urgent</option>
        </select>
      </div>
      <div class="form-group">
        <label class="form-label">Message</label>
        <textarea name="message" class="form-input" rows="5" placeholder="Describe your issue in detail..." required></textarea>
      </div>
      <button type="submit" class="btn btn-primary btn-block"><span>SUBMIT TICKET →</span></button>
    </form>
  </div>
  
  <div>
    <div class="card">
      <div class="card-title">💬 Quick Support</div>
      <a href="<?= htmlspecialchars($telegramLink) ?>" target="_blank" class="btn btn-secondary btn-block" style="margin-bottom:12px;">📱 JOIN TELEGRAM GROUP</a>
      <div style="font-size:.85rem;line-height:1.8;margin-top:16px;">
        <strong style="color:var(--white);">FAQ:</strong><br/>
        <strong>Q: How long for withdrawal?</strong><br/>
        A: Within 24 hours after admin approval.<br/><br/>
        <strong>Q: When is binary income paid?</strong><br/>
        A: Every Sunday (weekly).<br/><br/>
        <strong>Q: Can I upgrade from $50 to $100?</strong><br/>
        A: Yes! Go to Deposit → Select Upgrade.<br/><br/>
        <strong>Q: How to get referral income?</strong><br/>
        A: Share your referral link. Get 10% when they purchase a package.
      </div>
    </div>
  </div>
</div>

<!-- TICKET HISTORY -->
<div class="card">
  <div class="card-title">📋 My Tickets</div>
  <div class="table-wrap">
    <table>
      <thead><tr><th>ID</th><th>Subject</th><th>Priority</th><th>Status</th><th>Date</th><th>Reply</th></tr></thead>
      <tbody>
        <?php if(empty($tickets)): ?>
          <tr><td colspan="6" style="text-align:center;padding:24px;">No tickets yet</td></tr>
        <?php else: foreach($tickets as $t): ?>
          <tr>
            <td>#<?= $t['id'] ?></td>
            <td style="color:var(--white);"><?= htmlspecialchars($t['subject']) ?></td>
            <td><span class="badge badge-<?= $t['priority']==='urgent'?'red':($t['priority']==='high'?'pink':($t['priority']==='medium'?'gold':'cyan')) ?>"><?= strtoupper($t['priority']) ?></span></td>
            <td><span class="badge badge-<?= $t['status']==='resolved'?'green':($t['status']==='open'?'gold':'cyan') ?>"><?= strtoupper($t['status']) ?></span></td>
            <td><?= date('d M, H:i', strtotime($t['created_at'])) ?></td>
            <td><?= $t['admin_reply'] ? '<span style="color:var(--green);font-size:.82rem;">'.htmlspecialchars(substr($t['admin_reply'],0,50)).'...</span>' : '<span style="color:var(--text);font-size:.82rem;">Awaiting</span>' ?></td>
          </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php include 'includes/footer.php'; ?>
