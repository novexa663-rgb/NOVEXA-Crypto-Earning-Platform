<?php
require_once 'config.php';
requireLogin();
$pageTitle = 'Transactions';
$user = getUser($_SESSION['user_id']);

$filter = $_GET['type'] ?? 'all';
$where = "WHERE user_id = ?";
$params = [$user['id']];
if($filter !== 'all' && in_array($filter, ['deposit','withdrawal','roi_credit','referral_credit','binary_credit','direct_sponsor','bonus'])) {
    $where .= " AND type = ?";
    $params[] = $filter;
}

$stmt = $pdo->prepare("SELECT * FROM transactions $where ORDER BY created_at DESC LIMIT 100");
$stmt->execute($params); $txns = $stmt->fetchAll(PDO::FETCH_ASSOC);

include 'includes/header.php';
?>

<!-- FILTER TABS -->
<div class="tabs" style="flex-wrap:wrap;">
  <a href="?type=all" class="tab <?= $filter==='all'?'active':'' ?>">ALL</a>
  <a href="?type=deposit" class="tab <?= $filter==='deposit'?'active':'' ?>">DEPOSITS</a>
  <a href="?type=withdrawal" class="tab <?= $filter==='withdrawal'?'active':'' ?>">WITHDRAWALS</a>
  <a href="?type=roi_credit" class="tab <?= $filter==='roi_credit'?'active':'' ?>">ROI</a>
  <a href="?type=referral_credit" class="tab <?= $filter==='referral_credit'?'active':'' ?>">REFERRAL</a>
  <a href="?type=binary_credit" class="tab <?= $filter==='binary_credit'?'active':'' ?>">BINARY</a>
  <a href="?type=direct_sponsor" class="tab <?= $filter==='direct_sponsor'?'active':'' ?>">DIRECT</a>
</div>

<div class="card">
  <div class="card-title">📋 Transaction History — <?= strtoupper(str_replace('_',' ',$filter)) ?></div>
  <div class="table-wrap">
    <table>
      <thead><tr><th>Type</th><th>Amount</th><th>Coin</th><th>Description</th><th>Status</th><th>Date</th></tr></thead>
      <tbody>
        <?php if(empty($txns)): ?>
          <tr><td colspan="6" style="text-align:center;padding:24px;">No transactions found</td></tr>
        <?php else: foreach($txns as $tx): ?>
          <tr>
            <td><span class="badge badge-purple"><?= strtoupper(str_replace('_',' ',$tx['type'])) ?></span></td>
            <td style="color:<?= in_array($tx['type'],['withdrawal','service_charge'])?'var(--red)':'var(--green)' ?>;font-weight:600;"><?= in_array($tx['type'],['withdrawal','service_charge'])?'-':'+' ?><?= money($tx['amount']) ?></td>
            <td><?= strtoupper($tx['coin_type']) ?></td>
            <td style="font-size:.82rem;"><?= htmlspecialchars($tx['description'] ?: '-') ?></td>
            <td><span class="badge badge-<?= $tx['status']==='completed'?'green':($tx['status']==='pending'?'gold':'red') ?>"><?= strtoupper($tx['status']) ?></span></td>
            <td style="font-size:.8rem;"><?= date('d M Y, H:i', strtotime($tx['created_at'])) ?></td>
          </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php include 'includes/footer.php'; ?>
