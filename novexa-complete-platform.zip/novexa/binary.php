<?php
require_once 'config.php';
requireLogin();
$pageTitle = 'Binary';
$user = getUser($_SESSION['user_id']);

$stmt = $pdo->prepare("SELECT * FROM binary_tree WHERE user_id = ?");
$stmt->execute([$user['id']]); $tree = $stmt->fetch(PDO::FETCH_ASSOC);
if(!$tree) $tree = ['left_volume'=>0,'right_volume'=>0,'carry_left'=>0,'carry_right'=>0,'total_left_members'=>0,'total_right_members'=>0,'matching_income'=>0,'left_child_id'=>null,'right_child_id'=>null];

$stmt = $pdo->prepare("SELECT COALESCE(SUM(amount),0) FROM income WHERE user_id = ? AND type = 'binary'");
$stmt->execute([$user['id']]); $totalBinary = $stmt->fetchColumn();

// Get left & right direct children names
$leftUser = $tree['left_child_id'] ? getUser($tree['left_child_id']) : null;
$rightUser = $tree['right_child_id'] ? getUser($tree['right_child_id']) : null;

$stmt = $pdo->prepare("SELECT * FROM income WHERE user_id = ? AND type = 'binary' ORDER BY created_at DESC LIMIT 15");
$stmt->execute([$user['id']]); $binaryIncomes = $stmt->fetchAll(PDO::FETCH_ASSOC);

include 'includes/header.php';
?>

<div class="stat-grid">
  <div class="stat-card purple">
    <div class="stat-label">Left Team</div>
    <div class="stat-value"><?= $tree['total_left_members'] ?></div>
    <div class="stat-sub">Members</div>
  </div>
  <div class="stat-card pink">
    <div class="stat-label">Right Team</div>
    <div class="stat-value"><?= $tree['total_right_members'] ?></div>
    <div class="stat-sub">Members</div>
  </div>
  <div class="stat-card gold">
    <div class="stat-label">Left Volume</div>
    <div class="stat-value"><?= money($tree['left_volume']) ?></div>
  </div>
  <div class="stat-card cyan">
    <div class="stat-label">Right Volume</div>
    <div class="stat-value"><?= money($tree['right_volume']) ?></div>
  </div>
  <div class="stat-card green">
    <div class="stat-label">Matching Income</div>
    <div class="stat-value"><?= money($totalBinary) ?></div>
  </div>
  <div class="stat-card red">
    <div class="stat-label">Daily Cap</div>
    <div class="stat-value">$100</div>
  </div>
</div>

<!-- CARRY FORWARD -->
<div class="grid-2">
  <div class="card">
    <div class="card-title">📊 Carry Forward Volume</div>
    <div style="display:flex;gap:20px;">
      <div style="flex:1;text-align:center;padding:20px;background:rgba(236,72,153,.05);border:1px solid rgba(236,72,153,.15);">
        <div style="font-family:'JetBrains Mono',monospace;font-size:.6rem;letter-spacing:2px;color:var(--text);margin-bottom:6px;">LEFT CARRY</div>
        <div style="font-family:'Syne',sans-serif;font-size:1.4rem;font-weight:800;color:var(--pink);"><?= money($tree['carry_left']) ?></div>
      </div>
      <div style="flex:1;text-align:center;padding:20px;background:rgba(245,158,11,.05);border:1px solid rgba(245,158,11,.15);">
        <div style="font-family:'JetBrains Mono',monospace;font-size:.6rem;letter-spacing:2px;color:var(--text);margin-bottom:6px;">RIGHT CARRY</div>
        <div style="font-family:'Syne',sans-serif;font-size:1.4rem;font-weight:800;color:var(--gold);"><?= money($tree['carry_right']) ?></div>
      </div>
    </div>
  </div>
  
  <!-- TREE VISUALIZATION -->
  <div class="card">
    <div class="card-title">🌳 Binary Tree</div>
    <div style="text-align:center;padding:16px 0;">
      <!-- YOU -->
      <div style="display:inline-block;padding:12px 24px;border:2px solid var(--v2);background:rgba(168,85,247,.1);margin-bottom:8px;">
        <div style="font-family:'Syne',sans-serif;font-weight:700;color:var(--white);font-size:.85rem;">👑 YOU</div>
        <div style="font-family:'JetBrains Mono',monospace;font-size:.6rem;color:var(--v2);"><?= $user['username'] ?></div>
      </div>
      
      <!-- CONNECTOR -->
      <div style="display:flex;justify-content:center;margin:4px 0;">
        <div style="width:1px;height:20px;background:var(--border);"></div>
      </div>
      <div style="display:flex;justify-content:center;">
        <div style="width:40%;height:1px;background:var(--border);"></div>
      </div>
      
      <!-- CHILDREN -->
      <div style="display:flex;justify-content:center;gap:40px;margin-top:4px;">
        <div>
          <div style="width:1px;height:20px;background:var(--border);margin:0 auto;"></div>
          <div style="display:inline-block;padding:10px 20px;border:1px solid <?= $leftUser?'var(--pink)':'var(--border)' ?>;background:<?= $leftUser?'rgba(236,72,153,.05)':'transparent' ?>;">
            <div style="font-family:'Syne',sans-serif;font-weight:700;color:<?= $leftUser?'var(--pink)':'var(--text)' ?>;font-size:.8rem;"><?= $leftUser ? $leftUser['username'] : 'EMPTY' ?></div>
            <div style="font-family:'JetBrains Mono',monospace;font-size:.55rem;color:var(--text);">LEFT LEG</div>
          </div>
        </div>
        <div>
          <div style="width:1px;height:20px;background:var(--border);margin:0 auto;"></div>
          <div style="display:inline-block;padding:10px 20px;border:1px solid <?= $rightUser?'var(--gold)':'var(--border)' ?>;background:<?= $rightUser?'rgba(245,158,11,.05)':'transparent' ?>;">
            <div style="font-family:'Syne',sans-serif;font-weight:700;color:<?= $rightUser?'var(--gold)':'var(--text)' ?>;font-size:.8rem;"><?= $rightUser ? $rightUser['username'] : 'EMPTY' ?></div>
            <div style="font-family:'JetBrains Mono',monospace;font-size:.55rem;color:var(--text);">RIGHT LEG</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- BINARY INCOME HISTORY -->
<div class="card">
  <div class="card-title">💰 Binary Income History</div>
  <div class="table-wrap">
    <table>
      <thead><tr><th>Amount</th><th>Description</th><th>Status</th><th>Date</th></tr></thead>
      <tbody>
        <?php if(empty($binaryIncomes)): ?>
          <tr><td colspan="4" style="text-align:center;padding:24px;">No binary income yet</td></tr>
        <?php else: foreach($binaryIncomes as $bi): ?>
          <tr>
            <td style="color:var(--green);font-weight:600;"><?= money($bi['amount']) ?></td>
            <td><?= htmlspecialchars($bi['description'] ?: 'Binary matching income') ?></td>
            <td><span class="badge badge-green"><?= strtoupper($bi['status']) ?></span></td>
            <td><?= date('d M, H:i', strtotime($bi['created_at'])) ?></td>
          </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php include 'includes/footer.php'; ?>
