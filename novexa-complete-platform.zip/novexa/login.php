<?php
require_once 'config.php';
if(isLoggedIn()) { header('Location: dashboard.php'); exit; }

$error = '';
if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    
    $stmt = $pdo->prepare("SELECT * FROM users WHERE (username = ? OR email = ?) AND status = 'active'");
    $stmt->execute([$username, $username]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $pdo->prepare("UPDATE users SET last_login = NOW() WHERE id = ?")->execute([$user['id']]);
        header('Location: dashboard.php');
        exit;
    } else {
        $error = 'Invalid username/email or password';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>Login — NOVEXA</title>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=DM+Sans:wght@400;500;600&family=JetBrains+Mono:wght@400;700&display=swap" rel="stylesheet"/>
<style>
:root{--v:#7C3AED;--v2:#A855F7;--v3:#C084FC;--pink:#EC4899;--bg:#020008;--border:rgba(168,85,247,.15);--text:#9CA3AF;--white:#F9FAFB;}
*{margin:0;padding:0;box-sizing:border-box;}
body{background:var(--bg);color:var(--text);font-family:'DM Sans',sans-serif;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px;}
.auth-card{width:100%;max-width:420px;background:rgba(255,255,255,.02);border:1px solid var(--border);padding:48px 40px;position:relative;overflow:hidden;}
.auth-card::before{content:'';position:absolute;top:0;left:0;right:0;height:2px;background:linear-gradient(90deg,var(--v),var(--pink),var(--v2));}
.logo{font-family:'Syne',sans-serif;font-size:1.6rem;font-weight:800;letter-spacing:5px;text-align:center;background:linear-gradient(135deg,var(--v2),var(--pink));-webkit-background-clip:text;background-clip:text;color:transparent;margin-bottom:8px;}
.tagline{text-align:center;font-family:'JetBrains Mono',monospace;font-size:.6rem;letter-spacing:3px;color:var(--text);margin-bottom:36px;}
.form-group{margin-bottom:18px;}
.form-label{display:block;font-family:'JetBrains Mono',monospace;font-size:.62rem;font-weight:700;letter-spacing:2px;text-transform:uppercase;color:var(--text);margin-bottom:6px;}
.form-input{width:100%;padding:13px 16px;background:rgba(255,255,255,.03);border:1px solid var(--border);color:var(--white);font-family:'DM Sans',sans-serif;font-size:.88rem;outline:none;transition:border-color .2s;}
.form-input:focus{border-color:var(--v2);}
.form-input::placeholder{color:rgba(156,163,175,.3);}
.btn{width:100%;padding:14px;background:linear-gradient(135deg,var(--v),var(--v2));border:none;color:#fff;font-family:'Syne',sans-serif;font-size:.85rem;font-weight:700;letter-spacing:2px;cursor:pointer;clip-path:polygon(8px 0,100% 0,calc(100% - 8px) 100%,0 100%);margin-top:8px;transition:filter .2s;}
.btn:hover{filter:brightness(1.15);}
.links{display:flex;justify-content:space-between;margin-top:20px;font-size:.82rem;}
.links a{color:var(--v2);text-decoration:none;transition:color .2s;}
.links a:hover{color:var(--pink);}
.error{background:rgba(239,68,68,.08);border-left:3px solid #EF4444;padding:12px;color:#EF4444;font-size:.83rem;margin-bottom:18px;}
.glow{position:fixed;width:300px;height:300px;border-radius:50%;background:radial-gradient(circle,rgba(124,58,237,.08),transparent 70%);pointer-events:none;}
</style>
</head>
<body>
<div class="glow" style="top:10%;left:10%;"></div>
<div class="glow" style="bottom:10%;right:10%;background:radial-gradient(circle,rgba(236,72,153,.06),transparent 70%);"></div>

<div class="auth-card">
  <div class="logo">NOVEXA</div>
  <div class="tagline">◆ BEYOND THE HORIZON ◆</div>
  
  <?php if($error): ?><div class="error"><?= $error ?></div><?php endif; ?>
  
  <form method="POST">
    <div class="form-group">
      <label class="form-label">Username or Email</label>
      <input type="text" name="username" class="form-input" placeholder="Enter username or email" required/>
    </div>
    <div class="form-group">
      <label class="form-label">Password</label>
      <input type="password" name="password" class="form-input" placeholder="Enter password" required/>
    </div>
    <button type="submit" class="btn">LOGIN →</button>
  </form>
  
  <div class="links">
    <a href="forgot_password.php">Forgot Password?</a>
    <a href="register.php">Create Account →</a>
  </div>
</div>
</body>
</html>
