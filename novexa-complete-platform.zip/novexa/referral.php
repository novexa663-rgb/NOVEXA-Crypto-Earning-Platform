<?php
require_once 'config.php';
requireLogin();
$pageTitle = 'Referral';
$user = getUser($_SESSION['user_id']);
$refLink = 'https://novexa.org.in/register.php?ref=' . $user['referral_code'];

$stmt = $pdo->prepare("SELECT r.*, u.username, u.full_name, u.active_package, u.created_at as joined FROM referrals r JOIN users u ON r.referred_id = u.id WHERE r.sponsor_id = ? ORDER BY r.created_at DESC");
$stmt->execute([$user['id']]); $referrals = $stmt->fetchAll(PDO::FETCH_ASSOC);

$stmt = $pdo->prepare("SELECT COUNT(*) FROM referrals WHERE sponsor_id = ? AND status = 'active'");
$stmt->execute([$user['id']]); $activeRefs = $stmt->fetchColumn();

$stmt = $pdo->prepare("SELECT COALESCE(SUM(amount),0) FROM income WHERE user_id = ? AND type IN ('referral','direct_sponsor')");
$stmt->execute([$user['id']]); $totalRefIncome = $stmt->fetchColumn();

$stmt = $pdo->prepare("SELECT * FROM income WHERE user_id = ? AND type IN ('referral','direct_sponsor') ORDER BY created_at DESC LIMIT 20");
$stmt->execute([$user['id']]); $refIncomes = $stmt->fetchAll(PDO::FETCH_ASSOC);

include 'includes/header.php';
?>

<div class="stat-grid">
  <div class="stat-card purple">
    <div class="stat-label">Total Referrals</div>
    <div class="stat-value"><?= count($referrals) ?></div>
  </div>
  <div class="stat-card green">
    <div class="stat-label">Active Referrals</div>
    <div class="stat-value"><?= $activeRefs ?></div>
  </div>
  <div class="stat-card pink">
    <div class="stat-label">Referral Income</div>
    <div class="stat-value"><?= money($totalRefIncome) ?></div>
  </div>
  <div class="stat-card gold">
    <div class="stat-label">Commission Rate</div>
    <div class="stat-value">10%</div>
  </div>
</div>

<div class="card">
  <div class="card-title">🔗 Your Referral Link</div>
  <div class="copy-wrap">
    <input type="text" class="form-input" value="<?= $refLink ?>" readonly/>
    <button class="copy-btn" onclick="copyText('<?= $refLink ?>')">COPY</button>
  </div>
  <div style="margin-top:8px;font-family:'JetBrains Mono',monospace;font-size:.7rem;color:var(--v2);">Code: <strong><?= $user['referral_code'] ?></strong></div>
</div>

<div class="grid-2">
  <div class="card">
    <div class="card-title">👥 My Referrals</div>
    <div class="table-wrap">
      <table>
        <thead><tr><th>User</th><th>Package</th><th>Status</th><th>Joined</th></tr></thead>
        <tbody>
          <?php if(empty($referrals)): ?>
            <tr><td colspan="4" style="text-align:center;padding:24px;">No referrals yet. Share your link!</td></tr>
          <?php else: foreach($referrals as $r): ?>
            <tr>
              <td style="color:var(--white);"><?= htmlspecialchars($r['username']) ?><br/><span style="font-size:.75rem;color:var(--text);"><?= htmlspecialchars($r['full_name']) ?></span></td>
              <td><span class="badge badge-<?= $r['active_package']!=='none'?'green':'gold' ?>"><?= strtoupper($r['active_package']) ?></span></td>
              <td><span class="badge badge-<?= $r['status']==='active'?'green':'red' ?>"><?= strtoupper($r['status']) ?></span></td>
              <td><?= date('d M Y', strtotime($r['joined'])) ?></td>
            </tr>
          <?php endforeach; endif; ?>
        </tbody>
      </table>
    </div>
  </div>
  
  <div class="card">
    <div class="card-title">💰 Referral Income History</div>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Type</th><th>Amount</th><th>Date</th></tr></thead>
        <tbody>
          <?php if(empty($refIncomes)): ?>
            <tr><td colspan="3" style="text-align:center;padding:24px;">No income yet</td></tr>
          <?php else: foreach($refIncomes as $ri): ?>
            <tr>
              <td><span class="badge badge-pink"><?= strtoupper(str_replace('_',' ',$ri['type'])) ?></span></td>
              <td style="color:var(--green);font-weight:600;"><?= money($ri['amount']) ?></td>
              <td><?= date('d M, H:i', strtotime($ri['created_at'])) ?></td>
            </tr>
          <?php endforeach; endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php include 'includes/footer.php'; ?>
