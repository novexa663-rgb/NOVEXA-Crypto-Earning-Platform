<?php
require_once 'config.php';
requireAdmin();

$section = $_GET['s'] ?? 'dashboard';

// Handle Actions
if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    // APPROVE DEPOSIT
    if($action === 'approve_deposit') {
        $did = intval($_POST['deposit_id']);
        $deposit = $pdo->prepare("SELECT * FROM deposits WHERE id = ?")->execute([$did]);
        $dep = $pdo->prepare("SELECT * FROM deposits WHERE id = ?");
        $dep->execute([$did]); $deposit = $dep->fetch(PDO::FETCH_ASSOC);
        if($deposit && $deposit['status'] === 'pending') {
            $pdo->prepare("UPDATE deposits SET status='approved' WHERE id=?")->execute([$did]);
            $pdo->prepare("UPDATE users SET active_package=?, package_amount=?, package_date=NOW() WHERE id=?")->execute([$deposit['package_type'], $deposit['amount'], $deposit['user_id']]);
            
            // Process sponsor commission (10%)
            $user = getUser($deposit['user_id']);
            if($user['sponsor_id']) {
                $commission = $deposit['amount'] * 0.10;
                $pdo->prepare("UPDATE users SET total_balance=total_balance+?, referral_balance=referral_balance+? WHERE id=?")->execute([$commission, $commission, $user['sponsor_id']]);
                $pdo->prepare("INSERT INTO income (user_id, type, amount, from_user_id, description) VALUES (?, 'direct_sponsor', ?, ?, ?)")->execute([$user['sponsor_id'], $commission, $user['id'], "10% commission from ".$user['username']."'s package"]);
                addTransaction($user['sponsor_id'], 'direct_sponsor', $commission, 'internal', "Referral commission from ".$user['username']);
                addNotification($user['sponsor_id'], 'Referral Commission!', "You earned \$$commission from ".$user['username']."'s package.", 'income');
            }
            
            // Create ROI schedule for upgrade package
            if($deposit['package_type'] === 'upgrade') {
                for($i=1; $i<=100; $i++) {
                    $releaseDate = date('Y-m-d', strtotime("+$i days"));
                    $pdo->prepare("INSERT INTO roi_history (user_id, day_number, daily_amount, total_released, total_remaining, status, release_date) VALUES (?,?,2.00,?,?,?,?)")->execute([$deposit['user_id'], $i, $i*2, 200-($i*2), 'pending', $releaseDate]);
                }
            }
            
            addNotification($deposit['user_id'], 'Deposit Approved!', "Your ".$deposit['package_type']." package has been activated.", 'system');
            setFlash('success', 'Deposit approved and package activated!');
        }
    }
    // REJECT DEPOSIT
    elseif($action === 'reject_deposit') {
        $did = intval($_POST['deposit_id']);
        $note = trim($_POST['admin_note'] ?? '');
        $pdo->prepare("UPDATE deposits SET status='rejected', admin_note=? WHERE id=?")->execute([$note, $did]);
        $dep = $pdo->prepare("SELECT user_id FROM deposits WHERE id=?"); $dep->execute([$did]); $d=$dep->fetch();
        if($d) addNotification($d['user_id'], 'Deposit Rejected', $note ?: 'Your deposit was rejected.', 'system');
        setFlash('error', 'Deposit rejected');
    }
    // APPROVE WITHDRAWAL
    elseif($action === 'approve_withdrawal') {
        $wid = intval($_POST['withdrawal_id']);
        $txnHash = trim($_POST['txn_hash'] ?? '');
        $pdo->prepare("UPDATE withdrawals SET status='approved', txn_hash=? WHERE id=?")->execute([$txnHash, $wid]);
        $wd = $pdo->prepare("SELECT * FROM withdrawals WHERE id=?"); $wd->execute([$wid]); $w=$wd->fetch(PDO::FETCH_ASSOC);
        if($w) {
            $pdo->prepare("UPDATE users SET total_withdrawn=total_withdrawn+? WHERE id=?")->execute([$w['amount'], $w['user_id']]);
            addNotification($w['user_id'], 'Withdrawal Approved!', "Your withdrawal of \$".$w['net_amount']." has been processed.", 'withdrawal');
        }
        setFlash('success', 'Withdrawal approved');
    }
    // REJECT WITHDRAWAL
    elseif($action === 'reject_withdrawal') {
        $wid = intval($_POST['withdrawal_id']);
        $note = trim($_POST['admin_note'] ?? '');
        $wd = $pdo->prepare("SELECT * FROM withdrawals WHERE id=?"); $wd->execute([$wid]); $w=$wd->fetch(PDO::FETCH_ASSOC);
        if($w) {
            $pdo->prepare("UPDATE withdrawals SET status='rejected', admin_note=? WHERE id=?")->execute([$note, $wid]);
            $pdo->prepare("UPDATE users SET total_balance=total_balance+? WHERE id=?")->execute([$w['amount'], $w['user_id']]);
            addNotification($w['user_id'], 'Withdrawal Rejected', $note ?: 'Your withdrawal was rejected. Amount refunded.', 'withdrawal');
        }
        setFlash('error', 'Withdrawal rejected, amount refunded');
    }
    // BLOCK/UNBLOCK USER
    elseif($action === 'toggle_user') {
        $uid = intval($_POST['user_id']);
        $status = $_POST['new_status'];
        $pdo->prepare("UPDATE users SET status=? WHERE id=?")->execute([$status, $uid]);
        setFlash('success', "User status updated to $status");
    }
    // VERIFY KYC
    elseif($action === 'verify_kyc') {
        $uid = intval($_POST['user_id']);
        $kycStatus = $_POST['kyc_status'];
        $pdo->prepare("UPDATE users SET kyc_status=? WHERE id=?")->execute([$kycStatus, $uid]);
        addNotification($uid, 'KYC '.$kycStatus, "Your KYC has been $kycStatus.", 'system');
        setFlash('success', "KYC $kycStatus");
    }
    // CREATE ANNOUNCEMENT
    elseif($action === 'create_announcement') {
        $stmt = $pdo->prepare("INSERT INTO announcements (title, message, type, display_type, target, is_pinned, is_active, start_date, end_date) VALUES (?,?,?,?,?,?,?,?,?)");
        $stmt->execute([
            $_POST['title'], $_POST['message'], $_POST['type'], $_POST['display_type'],
            $_POST['target'] ?? 'all', isset($_POST['is_pinned'])?1:0, 1,
            $_POST['start_date'] ?: null, $_POST['end_date'] ?: null
        ]);
        setFlash('success', 'Announcement created!');
    }
    // DELETE ANNOUNCEMENT
    elseif($action === 'delete_announcement') {
        $pdo->prepare("DELETE FROM announcements WHERE id=?")->execute([intval($_POST['ann_id'])]);
        setFlash('success', 'Announcement deleted');
    }
    // TOGGLE ANNOUNCEMENT
    elseif($action === 'toggle_announcement') {
        $aid = intval($_POST['ann_id']);
        $pdo->query("UPDATE announcements SET is_active = NOT is_active WHERE id = $aid");
        setFlash('success', 'Announcement toggled');
    }
    // REPLY TICKET
    elseif($action === 'reply_ticket') {
        $tid = intval($_POST['ticket_id']);
        $reply = trim($_POST['reply'] ?? '');
        $status = $_POST['ticket_status'] ?? 'resolved';
        $pdo->prepare("UPDATE support_tickets SET admin_reply=?, status=?, replied_at=NOW() WHERE id=?")->execute([$reply, $status, $tid]);
        $tk = $pdo->prepare("SELECT user_id FROM support_tickets WHERE id=?"); $tk->execute([$tid]); $t=$tk->fetch();
        if($t) addNotification($t['user_id'], 'Ticket Reply', "Your support ticket #$tid has been replied to.", 'system');
        setFlash('success', 'Ticket replied');
    }
    // UPDATE SETTINGS
    elseif($action === 'update_settings') {
        foreach($_POST as $key => $val) {
            if($key !== 'action') {
                $pdo->prepare("UPDATE settings SET setting_value=? WHERE setting_key=?")->execute([$val, $key]);
            }
        }
        setFlash('success', 'Settings updated!');
    }
    
    header("Location: admin.php?s=$section"); exit;
}

// STATS
$totalUsers = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$activeUsers = $pdo->query("SELECT COUNT(*) FROM users WHERE active_package != 'none'")->fetchColumn();
$pendingDeposits = $pdo->query("SELECT COUNT(*) FROM deposits WHERE status='pending'")->fetchColumn();
$pendingWithdrawals = $pdo->query("SELECT COUNT(*) FROM withdrawals WHERE status='pending'")->fetchColumn();
$totalDeposited = $pdo->query("SELECT COALESCE(SUM(amount),0) FROM deposits WHERE status='approved'")->fetchColumn();
$totalWithdrawn = $pdo->query("SELECT COALESCE(SUM(net_amount),0) FROM withdrawals WHERE status='approved'")->fetchColumn();
$totalRevenue = $pdo->query("SELECT COALESCE(SUM(service_charge),0) FROM withdrawals WHERE status='approved'")->fetchColumn();
$openTickets = $pdo->query("SELECT COUNT(*) FROM support_tickets WHERE status='open'")->fetchColumn();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>Admin Panel — NOVEXA</title>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@600;700;800&family=DM+Sans:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500;700&display=swap" rel="stylesheet"/>
<style>
:root{--v:#7C3AED;--v2:#A855F7;--v3:#C084FC;--pink:#EC4899;--gold:#F59E0B;--cyan:#06B6D4;--green:#10B981;--red:#EF4444;--bg:#020008;--bg2:#0A0018;--card:rgba(255,255,255,.03);--border:rgba(168,85,247,.15);--text:#9CA3AF;--white:#F9FAFB;}
*{margin:0;padding:0;box-sizing:border-box;}
body{background:var(--bg);color:var(--text);font-family:'DM Sans',sans-serif;}
a{color:var(--v2);text-decoration:none;}
.layout{display:flex;min-height:100vh;}
.sidebar{width:240px;background:var(--bg2);border-right:1px solid var(--border);position:fixed;top:0;left:0;bottom:0;padding:20px 0;overflow-y:auto;z-index:100;}
.sb-logo{padding:0 20px 16px;font-family:'Syne',sans-serif;font-size:1.1rem;font-weight:800;letter-spacing:3px;color:var(--pink);border-bottom:1px solid var(--border);}
.sb-nav{padding:12px 0;}
.sb-item{display:flex;align-items:center;gap:10px;padding:10px 20px;color:var(--text);font-size:.82rem;font-weight:500;border-left:2px solid transparent;transition:all .2s;}
.sb-item:hover{background:rgba(236,72,153,.06);color:var(--white);border-left-color:var(--pink);}
.sb-item.active{background:rgba(236,72,153,.1);color:var(--white);border-left-color:var(--pink);}
.sb-badge{margin-left:auto;background:var(--red);color:#fff;font-size:.55rem;padding:2px 5px;border-radius:8px;font-family:'JetBrains Mono',monospace;}
.main{margin-left:240px;flex:1;padding:24px;}
.topbar{display:flex;justify-content:space-between;align-items:center;margin-bottom:24px;}
.topbar h1{font-family:'Syne',sans-serif;font-size:1.2rem;font-weight:700;color:var(--white);}
.stat-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:12px;margin-bottom:24px;}
.stat-card{background:var(--card);border:1px solid var(--border);padding:16px;position:relative;}
.stat-card::before{content:'';position:absolute;top:0;left:0;width:2px;height:100%;}
.stat-card.p::before{background:var(--v2);}.stat-card.pk::before{background:var(--pink);}.stat-card.g::before{background:var(--gold);}.stat-card.c::before{background:var(--cyan);}.stat-card.gr::before{background:var(--green);}.stat-card.r::before{background:var(--red);}
.stat-label{font-family:'JetBrains Mono',monospace;font-size:.58rem;font-weight:700;letter-spacing:2px;text-transform:uppercase;color:var(--text);margin-bottom:6px;}
.stat-value{font-family:'Syne',sans-serif;font-size:1.4rem;font-weight:800;color:var(--white);}
.card{background:var(--card);border:1px solid var(--border);padding:20px;margin-bottom:16px;}
.card-title{font-family:'Syne',sans-serif;font-size:.95rem;font-weight:700;color:var(--white);margin-bottom:14px;}
table{width:100%;border-collapse:collapse;}
th{font-family:'JetBrains Mono',monospace;font-size:.58rem;font-weight:700;letter-spacing:2px;text-transform:uppercase;color:var(--text);text-align:left;padding:10px 12px;border-bottom:1px solid var(--border);background:rgba(168,85,247,.04);}
td{padding:10px 12px;border-bottom:1px solid rgba(168,85,247,.06);font-size:.82rem;}
tr:hover td{background:rgba(168,85,247,.03);}
.badge{display:inline-block;padding:2px 6px;font-family:'JetBrains Mono',monospace;font-size:.55rem;font-weight:700;letter-spacing:1px;border-radius:2px;}
.badge-green{background:rgba(16,185,129,.15);color:var(--green);}
.badge-red{background:rgba(239,68,68,.15);color:var(--red);}
.badge-gold{background:rgba(245,158,11,.15);color:var(--gold);}
.badge-purple{background:rgba(168,85,247,.15);color:var(--v2);}
.badge-cyan{background:rgba(6,182,212,.15);color:var(--cyan);}
.badge-pink{background:rgba(236,72,153,.15);color:var(--pink);}
.btn{padding:6px 14px;border:none;font-family:'Syne',sans-serif;font-size:.68rem;font-weight:700;letter-spacing:1px;cursor:pointer;transition:all .2s;display:inline-flex;align-items:center;gap:6px;}
.btn-green{background:rgba(16,185,129,.2);color:var(--green);border:1px solid rgba(16,185,129,.3);}
.btn-green:hover{background:rgba(16,185,129,.3);}
.btn-red{background:rgba(239,68,68,.2);color:var(--red);border:1px solid rgba(239,68,68,.3);}
.btn-red:hover{background:rgba(239,68,68,.3);}
.btn-purple{background:rgba(168,85,247,.2);color:var(--v2);border:1px solid rgba(168,85,247,.3);}
.btn-purple:hover{background:rgba(168,85,247,.3);}
.btn-pink{background:rgba(236,72,153,.2);color:var(--pink);border:1px solid rgba(236,72,153,.3);}
.form-group{margin-bottom:12px;}
.form-label{display:block;font-family:'JetBrains Mono',monospace;font-size:.6rem;font-weight:700;letter-spacing:2px;text-transform:uppercase;color:var(--text);margin-bottom:4px;}
.form-input{width:100%;padding:10px 14px;background:rgba(255,255,255,.03);border:1px solid var(--border);color:var(--white);font-family:'DM Sans',sans-serif;font-size:.84rem;outline:none;}
.form-input:focus{border-color:var(--pink);}
select.form-input{cursor:pointer;}
textarea.form-input{resize:vertical;min-height:60px;}
.grid-2{display:grid;grid-template-columns:1fr 1fr;gap:16px;}
.flash{padding:12px;margin-bottom:16px;font-size:.82rem;border-left:3px solid;}
.flash-success{background:rgba(16,185,129,.08);border-color:var(--green);color:var(--green);}
.flash-error{background:rgba(239,68,68,.08);border-color:var(--red);color:var(--red);}
@media(max-width:768px){.sidebar{display:none;}.main{margin-left:0;padding:16px;}.stat-grid{grid-template-columns:1fr 1fr;}.grid-2{grid-template-columns:1fr;}}
</style>
</head>
<body>
<div class="layout">
<aside class="sidebar">
  <div class="sb-logo">🛡️ ADMIN</div>
  <nav class="sb-nav">
    <a href="?s=dashboard" class="sb-item <?=$section==='dashboard'?'active':''?>">📊 Dashboard</a>
    <a href="?s=users" class="sb-item <?=$section==='users'?'active':''?>">👥 Users</a>
    <a href="?s=deposits" class="sb-item <?=$section==='deposits'?'active':''?>">💳 Deposits <?php if($pendingDeposits):?><span class="sb-badge"><?=$pendingDeposits?></span><?php endif;?></a>
    <a href="?s=withdrawals" class="sb-item <?=$section==='withdrawals'?'active':''?>">🏧 Withdrawals <?php if($pendingWithdrawals):?><span class="sb-badge"><?=$pendingWithdrawals?></span><?php endif;?></a>
    <a href="?s=roi" class="sb-item <?=$section==='roi'?'active':''?>">📈 ROI Control</a>
    <a href="?s=binary" class="sb-item <?=$section==='binary'?'active':''?>">🌳 Binary</a>
    <a href="?s=announcements" class="sb-item <?=$section==='announcements'?'active':''?>">📢 Announcements</a>
    <a href="?s=tickets" class="sb-item <?=$section==='tickets'?'active':''?>">🎧 Support <?php if($openTickets):?><span class="sb-badge"><?=$openTickets?></span><?php endif;?></a>
    <a href="?s=reports" class="sb-item <?=$section==='reports'?'active':''?>">📋 Reports</a>
    <a href="?s=settings" class="sb-item <?=$section==='settings'?'active':''?>">⚙️ Settings</a>
    <a href="admin_logout.php" class="sb-item">🚪 Logout</a>
  </nav>
</aside>

<div class="main">
<?php $flash = getFlash(); if($flash): ?><div class="flash flash-<?=$flash['type']?>"><?=$flash['message']?></div><?php endif; ?>

<?php if($section === 'dashboard'): ?>
<!-- ═══════ DASHBOARD ═══════ -->
<div class="topbar"><h1>Admin Dashboard</h1></div>
<div class="stat-grid">
  <div class="stat-card p"><div class="stat-label">Total Users</div><div class="stat-value"><?=$totalUsers?></div></div>
  <div class="stat-card gr"><div class="stat-label">Active Users</div><div class="stat-value"><?=$activeUsers?></div></div>
  <div class="stat-card g"><div class="stat-label">Pending Deposits</div><div class="stat-value"><?=$pendingDeposits?></div></div>
  <div class="stat-card r"><div class="stat-label">Pending Withdrawals</div><div class="stat-value"><?=$pendingWithdrawals?></div></div>
  <div class="stat-card c"><div class="stat-label">Total Deposited</div><div class="stat-value"><?=money($totalDeposited)?></div></div>
  <div class="stat-card pk"><div class="stat-label">Total Withdrawn</div><div class="stat-value"><?=money($totalWithdrawn)?></div></div>
  <div class="stat-card gr"><div class="stat-label">Revenue (Charges)</div><div class="stat-value"><?=money($totalRevenue)?></div></div>
  <div class="stat-card g"><div class="stat-label">Open Tickets</div><div class="stat-value"><?=$openTickets?></div></div>
</div>

<?php elseif($section === 'users'): ?>
<!-- ═══════ USERS ═══════ -->
<div class="topbar"><h1>User Management</h1></div>
<?php
$search = $_GET['q'] ?? '';
$sql = "SELECT * FROM users";
$params = [];
if($search) { $sql .= " WHERE username LIKE ? OR email LIKE ? OR full_name LIKE ?"; $params = ["%$search%","%$search%","%$search%"]; }
$sql .= " ORDER BY created_at DESC LIMIT 100";
$stmt = $pdo->prepare($sql); $stmt->execute($params); $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<div class="card">
  <form method="GET" style="display:flex;gap:8px;margin-bottom:16px;">
    <input type="hidden" name="s" value="users"/>
    <input type="text" name="q" class="form-input" placeholder="Search username, email, name..." value="<?=htmlspecialchars($search)?>" style="max-width:300px;"/>
    <button class="btn btn-purple">SEARCH</button>
  </form>
  <div style="overflow-x:auto;">
  <table>
    <thead><tr><th>ID</th><th>Name</th><th>Username</th><th>Email</th><th>Package</th><th>Balance</th><th>KYC</th><th>Status</th><th>Actions</th></tr></thead>
    <tbody>
    <?php foreach($users as $u): ?>
      <tr>
        <td><?=$u['id']?></td>
        <td style="color:var(--white);"><?=htmlspecialchars($u['full_name'])?></td>
        <td style="font-family:'JetBrains Mono',monospace;font-size:.75rem;"><?=htmlspecialchars($u['username'])?></td>
        <td style="font-size:.78rem;"><?=htmlspecialchars($u['email'])?></td>
        <td><span class="badge badge-<?=$u['active_package']!=='none'?'purple':'gold'?>"><?=strtoupper($u['active_package'])?></span></td>
        <td style="color:var(--green);"><?=money($u['total_balance'])?></td>
        <td><span class="badge badge-<?=$u['kyc_status']==='verified'?'green':($u['kyc_status']==='submitted'?'gold':'red')?>"><?=strtoupper($u['kyc_status'])?></span></td>
        <td><span class="badge badge-<?=$u['status']==='active'?'green':'red'?>"><?=strtoupper($u['status'])?></span></td>
        <td style="white-space:nowrap;">
          <form method="POST" style="display:inline;">
            <input type="hidden" name="action" value="toggle_user"/>
            <input type="hidden" name="user_id" value="<?=$u['id']?>"/>
            <?php if($u['status']==='active'): ?>
              <input type="hidden" name="new_status" value="blocked"/>
              <button class="btn btn-red">BLOCK</button>
            <?php else: ?>
              <input type="hidden" name="new_status" value="active"/>
              <button class="btn btn-green">UNBLOCK</button>
            <?php endif; ?>
          </form>
          <?php if($u['kyc_status']==='submitted'): ?>
          <form method="POST" style="display:inline;margin-left:4px;">
            <input type="hidden" name="action" value="verify_kyc"/>
            <input type="hidden" name="user_id" value="<?=$u['id']?>"/>
            <input type="hidden" name="kyc_status" value="verified"/>
            <button class="btn btn-green">✓KYC</button>
          </form>
          <?php endif; ?>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  </div>
</div>

<?php elseif($section === 'deposits'): ?>
<!-- ═══════ DEPOSITS ═══════ -->
<div class="topbar"><h1>Deposit Management</h1></div>
<?php
$dFilter = $_GET['f'] ?? 'pending';
$sql = "SELECT d.*, u.username, u.full_name FROM deposits d JOIN users u ON d.user_id=u.id";
if($dFilter !== 'all') $sql .= " WHERE d.status='$dFilter'";
$sql .= " ORDER BY d.created_at DESC LIMIT 100";
$deps = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
?>
<div style="display:flex;gap:8px;margin-bottom:16px;">
  <a href="?s=deposits&f=pending" class="btn <?=$dFilter==='pending'?'btn-pink':'btn-purple'?>">PENDING (<?=$pendingDeposits?>)</a>
  <a href="?s=deposits&f=approved" class="btn btn-purple">APPROVED</a>
  <a href="?s=deposits&f=rejected" class="btn btn-purple">REJECTED</a>
  <a href="?s=deposits&f=all" class="btn btn-purple">ALL</a>
</div>
<div class="card">
  <div style="overflow-x:auto;">
  <table>
    <thead><tr><th>ID</th><th>User</th><th>Package</th><th>Amount</th><th>TXN</th><th>Proof</th><th>Status</th><th>Date</th><th>Actions</th></tr></thead>
    <tbody>
    <?php foreach($deps as $d): ?>
      <tr>
        <td><?=$d['id']?></td>
        <td style="color:var(--white);"><?=htmlspecialchars($d['username'])?></td>
        <td><span class="badge badge-purple"><?=strtoupper($d['package_type'])?></span></td>
        <td style="color:var(--green);font-weight:600;"><?=money($d['amount'])?></td>
        <td style="font-family:'JetBrains Mono',monospace;font-size:.7rem;"><?=$d['txn_hash']?substr($d['txn_hash'],0,12).'...':'-'?></td>
        <td><?=$d['payment_proof']?'<a href="uploads/payment_proof/'.$d['payment_proof'].'" target="_blank" style="color:var(--cyan);">View</a>':'-'?></td>
        <td><span class="badge badge-<?=$d['status']==='approved'?'green':($d['status']==='pending'?'gold':'red')?>"><?=strtoupper($d['status'])?></span></td>
        <td style="font-size:.78rem;"><?=date('d M, H:i',strtotime($d['created_at']))?></td>
        <td>
          <?php if($d['status']==='pending'): ?>
          <form method="POST" style="display:inline;"><input type="hidden" name="action" value="approve_deposit"/><input type="hidden" name="deposit_id" value="<?=$d['id']?>"/><button class="btn btn-green">✓ APPROVE</button></form>
          <form method="POST" style="display:inline;margin-left:4px;"><input type="hidden" name="action" value="reject_deposit"/><input type="hidden" name="deposit_id" value="<?=$d['id']?>"/><input type="hidden" name="admin_note" value="Payment not found"/><button class="btn btn-red">✗ REJECT</button></form>
          <?php else: echo '-'; endif; ?>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  </div>
</div>

<?php elseif($section === 'withdrawals'): ?>
<!-- ═══════ WITHDRAWALS ═══════ -->
<div class="topbar"><h1>Withdrawal Management</h1></div>
<?php
$wFilter = $_GET['f'] ?? 'pending';
$sql = "SELECT w.*, u.username FROM withdrawals w JOIN users u ON w.user_id=u.id";
if($wFilter !== 'all') $sql .= " WHERE w.status='$wFilter'";
$sql .= " ORDER BY w.created_at DESC LIMIT 100";
$wds = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
?>
<div style="display:flex;gap:8px;margin-bottom:16px;">
  <a href="?s=withdrawals&f=pending" class="btn <?=$wFilter==='pending'?'btn-pink':'btn-purple'?>">PENDING (<?=$pendingWithdrawals?>)</a>
  <a href="?s=withdrawals&f=approved" class="btn btn-purple">APPROVED</a>
  <a href="?s=withdrawals&f=all" class="btn btn-purple">ALL</a>
</div>
<div class="card">
  <div style="overflow-x:auto;">
  <table>
    <thead><tr><th>ID</th><th>User</th><th>Amount</th><th>Charge</th><th>Net</th><th>Coin</th><th>Wallet</th><th>Status</th><th>Date</th><th>Actions</th></tr></thead>
    <tbody>
    <?php foreach($wds as $w): ?>
      <tr>
        <td><?=$w['id']?></td>
        <td style="color:var(--white);"><?=htmlspecialchars($w['username'])?></td>
        <td><?=money($w['amount'])?></td>
        <td style="color:var(--pink);"><?=money($w['service_charge'])?></td>
        <td style="color:var(--green);font-weight:600;"><?=money($w['net_amount'])?></td>
        <td><?=strtoupper($w['coin_type'])?></td>
        <td style="font-family:'JetBrains Mono',monospace;font-size:.68rem;"><?=substr($w['wallet_address'],0,12)?>...</td>
        <td><span class="badge badge-<?=$w['status']==='approved'?'green':($w['status']==='pending'?'gold':'red')?>"><?=strtoupper($w['status'])?></span></td>
        <td style="font-size:.78rem;"><?=date('d M, H:i',strtotime($w['created_at']))?></td>
        <td>
          <?php if($w['status']==='pending'): ?>
          <form method="POST" style="display:inline;"><input type="hidden" name="action" value="approve_withdrawal"/><input type="hidden" name="withdrawal_id" value="<?=$w['id']?>"/><input type="hidden" name="txn_hash" value=""/><button class="btn btn-green">✓</button></form>
          <form method="POST" style="display:inline;"><input type="hidden" name="action" value="reject_withdrawal"/><input type="hidden" name="withdrawal_id" value="<?=$w['id']?>"/><input type="hidden" name="admin_note" value=""/><button class="btn btn-red">✗</button></form>
          <?php else: echo $w['txn_hash']?'<span style="font-size:.68rem;">'.substr($w['txn_hash'],0,10).'</span>':'-'; endif; ?>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  </div>
</div>

<?php elseif($section === 'roi'): ?>
<!-- ═══════ ROI CONTROL ═══════ -->
<div class="topbar"><h1>ROI Control</h1></div>
<div class="card">
  <div class="card-title">⚡ Process Daily ROI</div>
  <p style="font-size:.85rem;margin-bottom:16px;">This will credit daily ROI to all eligible upgrade users for today.</p>
  <form method="POST">
    <input type="hidden" name="action" value="process_roi"/>
    <button class="btn btn-green" onclick="return confirm('Process daily ROI for all users?')">PROCESS TODAY'S ROI →</button>
  </form>
</div>
<?php
$roiStats = $pdo->query("SELECT u.username, COUNT(r.id) as days_done, SUM(CASE WHEN r.status='released' THEN r.daily_amount ELSE 0 END) as total_released FROM roi_history r JOIN users u ON r.user_id=u.id GROUP BY r.user_id ORDER BY total_released DESC LIMIT 20")->fetchAll(PDO::FETCH_ASSOC);
?>
<div class="card">
  <div class="card-title">📊 ROI Summary by User</div>
  <table>
    <thead><tr><th>User</th><th>Days Done</th><th>Total Released</th></tr></thead>
    <tbody>
    <?php foreach($roiStats as $rs): ?>
      <tr><td style="color:var(--white);"><?=$rs['username']?></td><td><?=$rs['days_done']?></td><td style="color:var(--green);"><?=money($rs['total_released'])?></td></tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>

<?php elseif($section === 'binary'): ?>
<!-- ═══════ BINARY ═══════ -->
<div class="topbar"><h1>Binary Settings</h1></div>
<?php $binaryData = $pdo->query("SELECT bt.*, u.username FROM binary_tree bt JOIN users u ON bt.user_id=u.id ORDER BY bt.matching_income DESC LIMIT 30")->fetchAll(PDO::FETCH_ASSOC); ?>
<div class="card">
  <div class="card-title">🌳 Binary Tree Overview</div>
  <table>
    <thead><tr><th>User</th><th>Left Vol</th><th>Right Vol</th><th>Left Members</th><th>Right Members</th><th>Carry Left</th><th>Carry Right</th><th>Income</th></tr></thead>
    <tbody>
    <?php foreach($binaryData as $b): ?>
      <tr>
        <td style="color:var(--white);"><?=$b['username']?></td>
        <td><?=money($b['left_volume'])?></td><td><?=money($b['right_volume'])?></td>
        <td><?=$b['total_left_members']?></td><td><?=$b['total_right_members']?></td>
        <td><?=money($b['carry_left'])?></td><td><?=money($b['carry_right'])?></td>
        <td style="color:var(--green);"><?=money($b['matching_income'])?></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>

<?php elseif($section === 'announcements'): ?>
<!-- ═══════ ANNOUNCEMENTS ═══════ -->
<div class="topbar"><h1>Announcements</h1></div>
<div class="grid-2">
  <div class="card">
    <div class="card-title">📢 Create Announcement</div>
    <form method="POST">
      <input type="hidden" name="action" value="create_announcement"/>
      <div class="form-group"><label class="form-label">Title</label><input type="text" name="title" class="form-input" required/></div>
      <div class="form-group"><label class="form-label">Message</label><textarea name="message" class="form-input" required></textarea></div>
      <div class="grid-2">
        <div class="form-group"><label class="form-label">Type</label>
          <select name="type" class="form-input"><option value="info">🔵 Info</option><option value="warning">🟡 Warning</option><option value="update">🟢 Update</option><option value="promotion">🔴 Promotion</option></select>
        </div>
        <div class="form-group"><label class="form-label">Display</label>
          <select name="display_type" class="form-input"><option value="scrollbar">Scrollbar</option><option value="popup">Popup Modal</option><option value="notification">Notification</option></select>
        </div>
      </div>
      <div class="grid-2">
        <div class="form-group"><label class="form-label">Start Date</label><input type="datetime-local" name="start_date" class="form-input"/></div>
        <div class="form-group"><label class="form-label">End Date</label><input type="datetime-local" name="end_date" class="form-input"/></div>
      </div>
      <div class="form-group"><label style="color:var(--text);font-size:.82rem;"><input type="checkbox" name="is_pinned" value="1"/> Pin this announcement</label></div>
      <button class="btn btn-pink">CREATE ANNOUNCEMENT →</button>
    </form>
  </div>
  <div class="card">
    <div class="card-title">📋 Active Announcements</div>
    <?php $anns = $pdo->query("SELECT * FROM announcements ORDER BY is_pinned DESC, created_at DESC")->fetchAll(PDO::FETCH_ASSOC); ?>
    <?php foreach($anns as $a): ?>
    <div style="padding:12px;border-bottom:1px solid var(--border);opacity:<?=$a['is_active']?1:.4?>;">
      <div style="display:flex;justify-content:space-between;align-items:center;">
        <div>
          <span class="badge badge-<?=$a['type']==='info'?'cyan':($a['type']==='warning'?'gold':($a['type']==='update'?'green':'pink'))?>"><?=strtoupper($a['type'])?></span>
          <?php if($a['is_pinned']): ?><span class="badge badge-purple">📌 PINNED</span><?php endif; ?>
          <strong style="color:var(--white);margin-left:6px;"><?=htmlspecialchars($a['title'])?></strong>
        </div>
        <div style="display:flex;gap:4px;">
          <form method="POST" style="display:inline;"><input type="hidden" name="action" value="toggle_announcement"/><input type="hidden" name="ann_id" value="<?=$a['id']?>"/><button class="btn <?=$a['is_active']?'btn-green':'btn-red'?>"><?=$a['is_active']?'ON':'OFF'?></button></form>
          <form method="POST" style="display:inline;" onsubmit="return confirm('Delete?')"><input type="hidden" name="action" value="delete_announcement"/><input type="hidden" name="ann_id" value="<?=$a['id']?>"/><button class="btn btn-red">✗</button></form>
        </div>
      </div>
      <div style="font-size:.8rem;margin-top:4px;"><?=htmlspecialchars(substr($a['message'],0,80))?></div>
    </div>
    <?php endforeach; ?>
  </div>
</div>

<?php elseif($section === 'tickets'): ?>
<!-- ═══════ SUPPORT TICKETS ═══════ -->
<div class="topbar"><h1>Support Tickets</h1></div>
<?php $tickets = $pdo->query("SELECT t.*, u.username FROM support_tickets t JOIN users u ON t.user_id=u.id ORDER BY FIELD(t.status,'open','in_progress','resolved','closed'), t.created_at DESC LIMIT 50")->fetchAll(PDO::FETCH_ASSOC); ?>
<div class="card">
  <table>
    <thead><tr><th>ID</th><th>User</th><th>Subject</th><th>Priority</th><th>Status</th><th>Date</th><th>Actions</th></tr></thead>
    <tbody>
    <?php foreach($tickets as $t): ?>
      <tr>
        <td>#<?=$t['id']?></td>
        <td style="color:var(--white);"><?=htmlspecialchars($t['username'])?></td>
        <td><?=htmlspecialchars($t['subject'])?><br/><span style="font-size:.75rem;"><?=htmlspecialchars(substr($t['message'],0,60))?>...</span></td>
        <td><span class="badge badge-<?=$t['priority']==='urgent'?'red':($t['priority']==='high'?'pink':'gold')?>"><?=strtoupper($t['priority'])?></span></td>
        <td><span class="badge badge-<?=$t['status']==='open'?'gold':($t['status']==='resolved'?'green':'cyan')?>"><?=strtoupper($t['status'])?></span></td>
        <td style="font-size:.78rem;"><?=date('d M, H:i',strtotime($t['created_at']))?></td>
        <td>
          <?php if($t['status']!=='closed'): ?>
          <form method="POST" style="display:flex;gap:4px;align-items:center;">
            <input type="hidden" name="action" value="reply_ticket"/>
            <input type="hidden" name="ticket_id" value="<?=$t['id']?>"/>
            <input type="text" name="reply" class="form-input" placeholder="Reply..." style="min-width:120px;padding:6px;font-size:.78rem;"/>
            <select name="ticket_status" style="padding:6px;background:var(--bg);color:var(--white);border:1px solid var(--border);font-size:.72rem;">
              <option value="resolved">Resolve</option><option value="in_progress">In Progress</option><option value="closed">Close</option>
            </select>
            <button class="btn btn-green">SEND</button>
          </form>
          <?php else: echo '<span style="color:var(--text);font-size:.78rem;">Closed</span>'; endif; ?>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>

<?php elseif($section === 'reports'): ?>
<!-- ═══════ REPORTS ═══════ -->
<div class="topbar"><h1>Reports</h1></div>
<?php
$todayIncome = $pdo->query("SELECT COALESCE(SUM(amount),0) FROM income WHERE DATE(created_at)=CURDATE()")->fetchColumn();
$todayWithdrawals = $pdo->query("SELECT COALESCE(SUM(amount),0) FROM withdrawals WHERE DATE(created_at)=CURDATE() AND status='approved'")->fetchColumn();
$todayDeposits = $pdo->query("SELECT COALESCE(SUM(amount),0) FROM deposits WHERE DATE(created_at)=CURDATE() AND status='approved'")->fetchColumn();
$weekIncome = $pdo->query("SELECT type, SUM(amount) as total FROM income WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY) GROUP BY type")->fetchAll(PDO::FETCH_ASSOC);
?>
<div class="stat-grid">
  <div class="stat-card gr"><div class="stat-label">Today Deposits</div><div class="stat-value"><?=money($todayDeposits)?></div></div>
  <div class="stat-card r"><div class="stat-label">Today Withdrawals</div><div class="stat-value"><?=money($todayWithdrawals)?></div></div>
  <div class="stat-card p"><div class="stat-label">Today Income Paid</div><div class="stat-value"><?=money($todayIncome)?></div></div>
  <div class="stat-card c"><div class="stat-label">Revenue (Charges)</div><div class="stat-value"><?=money($totalRevenue)?></div></div>
</div>
<div class="card">
  <div class="card-title">📊 Income Breakdown (7 Days)</div>
  <table>
    <thead><tr><th>Income Type</th><th>Total</th></tr></thead>
    <tbody>
    <?php foreach($weekIncome as $wi): ?>
      <tr><td><?=strtoupper(str_replace('_',' ',$wi['type']))?></td><td style="color:var(--green);font-weight:600;"><?=money($wi['total'])?></td></tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>

<?php elseif($section === 'settings'): ?>
<!-- ═══════ SETTINGS ═══════ -->
<div class="topbar"><h1>Platform Settings</h1></div>
<?php $settings = $pdo->query("SELECT * FROM settings ORDER BY id")->fetchAll(PDO::FETCH_ASSOC); ?>
<div class="card">
  <form method="POST">
    <input type="hidden" name="action" value="update_settings"/>
    <?php foreach($settings as $s): ?>
    <div class="form-group">
      <label class="form-label"><?=htmlspecialchars($s['description'] ?: $s['setting_key'])?></label>
      <input type="text" name="<?=$s['setting_key']?>" class="form-input" value="<?=htmlspecialchars($s['setting_value'])?>"/>
    </div>
    <?php endforeach; ?>
    <button class="btn btn-pink">SAVE ALL SETTINGS →</button>
  </form>
</div>
<?php endif; ?>

</div>
</div>
</body>
</html>
