<?php
require_once 'config.php';
requireLogin();
$pageTitle = 'Team';
$user = getUser($_SESSION['user_id']);

// Direct team
$stmt = $pdo->prepare("SELECT u.*, r.status as ref_status FROM users u JOIN referrals r ON u.id = r.referred_id WHERE r.sponsor_id = ? ORDER BY u.created_at DESC");
$stmt->execute([$user['id']]); $directTeam = $stmt->fetchAll(PDO::FETCH_ASSOC);

$totalDirect = count($directTeam);
$activeDirect = count(array_filter($directTeam, fn($m) => $m['active_package'] !== 'none'));
$inactiveDirect = $totalDirect - $activeDirect;

// Total network (simple recursive count)
$stmt = $pdo->prepare("SELECT COUNT(*) FROM binary_tree WHERE user_id = ?");
$stmt->execute([$user['id']]); $btree = $pdo->prepare("SELECT * FROM binary_tree WHERE user_id = ?");
$btree->execute([$user['id']]); $bt = $btree->fetch(PDO::FETCH_ASSOC);
$totalNetwork = $bt ? ($bt['total_left_members'] + $bt['total_right_members']) : 0;

include 'includes/header.php';
?>

<div class="stat-grid">
  <div class="stat-card purple">
    <div class="stat-label">Direct Team</div>
    <div class="stat-value"><?= $totalDirect ?></div>
  </div>
  <div class="stat-card green">
    <div class="stat-label">Active Members</div>
    <div class="stat-value"><?= $activeDirect ?></div>
  </div>
  <div class="stat-card red">
    <div class="stat-label">Inactive</div>
    <div class="stat-value"><?= $inactiveDirect ?></div>
  </div>
  <div class="stat-card cyan">
    <div class="stat-label">Total Network</div>
    <div class="stat-value"><?= $totalNetwork ?></div>
  </div>
</div>

<div class="card">
  <div class="card-title">👨‍👩‍👧‍👦 Direct Team Members</div>
  <div class="table-wrap">
    <table>
      <thead><tr><th>Name</th><th>Username</th><th>Package</th><th>Status</th><th>Joined</th></tr></thead>
      <tbody>
        <?php if(empty($directTeam)): ?>
          <tr><td colspan="5" style="text-align:center;padding:24px;">No team members yet. Share your referral link!</td></tr>
        <?php else: foreach($directTeam as $m): ?>
          <tr>
            <td style="color:var(--white);"><?= htmlspecialchars($m['full_name']) ?></td>
            <td style="font-family:'JetBrains Mono',monospace;font-size:.78rem;"><?= htmlspecialchars($m['username']) ?></td>
            <td><span class="badge badge-<?= $m['active_package']!=='none'?'purple':'gold' ?>"><?= strtoupper($m['active_package']) ?></span></td>
            <td><span class="badge badge-<?= $m['status']==='active'?'green':'red' ?>"><?= strtoupper($m['status']) ?></span></td>
            <td><?= date('d M Y', strtotime($m['created_at'])) ?></td>
          </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php include 'includes/footer.php'; ?>
